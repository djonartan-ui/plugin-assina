<?php

namespace Revela\DTO;

final class ProposalData {
	public int $proposal_id;
	public int $package_id;
	public string $package_title;
	public float $package_price;
	public string $package_category;
	public int $package_hours;
	public string $package_includes;
	public array $payment_plans;
	public array $extras;
	public string $event_date;
	public string $event_date_ext;
	public int $delivery_days;
	public string $client_name;
	public string $client_cpf;
	public string $client_email;
	public string $client_address;
	public string $client_cnpj;
	public array $client_locals;
	public float $entry_value;
	public string $selected_plan;
	public string $status;
	public string $token;
	public array $acceptance;
	public array $settings;

	public function __construct( array $data = [] ) {
		foreach ( $data as $key => $value ) {
			if ( property_exists( $this, $key ) ) {
				$this->$key = $value;
			}
		}
	}
}