<?php

namespace Revela\DTO;

final class Money {
	private int $cents;

	public function __construct( float|int|string $value ) {
		if ( is_string( $value ) ) {
			$value = str_replace( [ 'R$', ' ', ',', '.' ], [ '', '', '', '' ], $value );
			$value = (float) $value;
		}
		$this->cents = (int) round( (float) $value * 100 );
	}

	public static function fromCents( int $cents ): self {
		$obj = new self( 0 );
		$obj->cents = $cents;
		return $obj;
	}

	public function toFloat(): float {
		return $this->cents / 100;
	}

	public function toInt(): int {
		return $this->cents;
	}

	public function format( string $locale = 'pt_BR' ): string {
		return 'R$ ' . number_format( $this->toFloat(), 2, ',', '.' );
	}

	public function add( self $other ): self {
		return self::fromCents( $this->cents + $other->cents );
	}

	public function subtract( self $other ): self {
		return self::fromCents( $this->cents - $other->cents );
	}

	public function multiply( float $factor ): self {
		return self::fromCents( (int) round( $this->cents * $factor ) );
	}

	public function divide( int $divisor ): self {
		if ( $divisor === 0 ) {
			return self::fromCents( 0 );
		}
		return self::fromCents( (int) round( $this->cents / $divisor ) );
	}

	public function percentage( int $percent ): self {
		return self::fromCents( (int) round( $this->cents * $percent / 100 ) );
	}

	public function isZero(): bool {
		return $this->cents === 0;
	}

	public function isPositive(): bool {
		return $this->cents > 0;
	}

	public function __toString(): string {
		return $this->format();
	}
}