<?php

namespace Revela\Admin;

use Revela\Services\SettingsService;

final class SettingsPage {

	public static function register(): void {
		add_action( 'admin_menu', [ self::class, 'add_menu' ] );
		add_action( 'admin_init', [ self::class, 'register_settings' ] );
	}

	public static function add_menu(): void {
		add_submenu_page(
			'edit.php?post_type=' . \Revela\Models\Package::POST_TYPE,
			'Configurações REVELA',
			'Configurações',
			'manage_options',
			'revela-settings',
			[ self::class, 'render' ]
		);
	}

	public static function register_settings(): void {
		register_setting( 'revela_settings_group', 'revela_settings', [
			'type'              => 'array',
			'sanitize_callback' => [ SettingsService::class, 'sanitize' ],
			'show_in_rest'      => true,
		] );
	}

	public static function render(): void {
		$settings = SettingsService::instance()->get_all();
		$clauses_default = SettingsService::get_default_clauses();
		?>
		<div class="wrap revela-settings-wrap" style="max-width: 900px;">
			<h1 class="wp-heading-inline">Configurações REVELA v3</h1>
			<hr class="wp-header-end">

			<form method="post" action="options.php">
				<?php settings_fields( 'revela_settings_group' ); ?>

				<?php self::section_studio( $settings ); ?>
				<?php self::section_proposal( $settings ); ?>
				<?php self::section_legal( $settings ); ?>
				<?php self::section_security( $settings ); ?>
				<?php self::section_clauses( $settings, $clauses_default ); ?>

				<p class="description" style="margin-top:24px;padding:12px;background:#fff3cd;border-left:4px solid #ffc107;border-radius:4px;">
					<strong>⚠️ Importante:</strong> O contrato gerado é um modelo. Recomenda-se revisão por um advogado antes do uso.
				</p>

				<?php submit_button( 'Salvar configurações', 'primary', 'submit', true, [ 'id' => 'revela-save-btn' ] ); ?>
			</form>
		</div>
		<?php
	}

	private static function section_studio( array $settings ): void {
		?>
		<h2 class="revela-section-title" style="margin-top:32px;padding-top:16px;border-top:1px solid #dcdcde;">🏢 Estúdio (Contratada)</h2>
		<table class="form-table" role="presentation">
			<?php
			self::field_text( 'estudio', 'Nome do estúdio / empresa', $settings, 'Nome que aparecerá nos contratos e e-mails' );
			self::field_text( 'responsavel', 'Responsável legal', $settings, 'Nome do responsável pela empresa' );
			self::field_text( 'contato', 'Contato (telefone / e-mail / @)', $settings, 'Ex: (11) 99999-9999 / @estudio' );
			self::field_email( 'email_estudio', 'E-mail para receber contratos', $settings, 'Cópias dos contratos preenchidos serão enviadas para este e-mail' );
			self::field_text( 'documento', 'CNPJ / CPF', $settings, 'Documento da contratada' );
			self::field_textarea( 'endereco_estudio', 'Endereço completo do estúdio', $settings, 'Aparecerá no rodapé do contrato' );
			self::field_text( 'site_estudio', 'Site / link do estúdio', $settings, 'URL do portfólio ou site institucional' );
			?>
		</table>
		<?php
	}

	private static function section_proposal( array $settings ): void {
		?>
		<h2 class="revela-section-title" style="margin-top:32px;padding-top:16px;border-top:1px solid #dcdcde;">📋 Proposta</h2>
		<table class="form-table" role="presentation">
			<?php
			self::field_number( 'entrada_pct', 'Entrada padrão (%)', $settings, 'Percentual padrão da entrada (reserva)', 0, 100 );
			self::field_number( 'validade_dias', 'Validade da proposta (dias)', $settings, 'Dias até a proposta expirar automaticamente', 1, 365 );
			self::field_number( 'entrega_dias', 'Prazo de entrega (dias)', $settings, 'Dias após o evento para entrega do material', 1, 365 );
			?>
		</table>
		<?php
	}

	private static function section_legal( array $settings ): void {
		?>
		<h2 class="revela-section-title" style="margin-top:32px;padding-top:16px;border-top:1px solid #dcdcde;">⚖️ Jurídico</h2>
		<table class="form-table" role="presentation">
			<?php
			self::field_text( 'comarca', 'Comarca do foro (cidade)', $settings, 'Cidade do foro competente' );
			self::field_text( 'uf', 'UF', $settings, 'Sigla do estado (ex: RS)', '', 'width:80px' );
			self::field_text( 'cidade_assin', 'Cidade da assinatura', $settings, 'Cidade que constará na assinatura do contrato' );
			self::field_number( 'refund_pct', 'Devolução em cancelamento (%)', $settings, 'Percentual devolvido ao cliente em caso de cancelamento', 0, 100 );
			self::field_number( 'backup_meses', 'Backup dos arquivos (meses)', $settings, 'Tempo de garantia de backup dos arquivos', 1, 60 );
			self::field_number( 'nuvem_dias', 'Disponível na nuvem (dias)', $settings, 'Dias de acesso aos arquivos na nuvem após entrega', 1, 365 );
			self::field_number( 'taxa_arquivos', 'Taxa nova disponibilização (R$)', $settings, 'Custo para reativar link de download na nuvem', 0 );
			self::field_number( 'taxa_pendrive', 'Taxa novo pen drive (R$)', $settings, 'Custo para emissão de novo pen drive', 0 );
			?>
		</table>
		<?php
	}

	private static function section_security( array $settings ): void {
		?>
		<h2 class="revela-section-title" style="margin-top:32px;padding-top:16px;border-top:1px solid #dcdcde;">🔒 Segurança</h2>
		<table class="form-table" role="presentation">
			<?php
			self::field_number( 'nonce_lifetime', 'Validade do nonce (horas)', $settings, 'Tempo de expiração do token de segurança', 1, 168 );
			self::field_number( 'max_file_size', 'Tamanho máx. upload (MB)', $settings, 'Limite para upload de arquivos nos contratos', 1, 100 );
			?>
		</table>
		<?php
	}

	private static function section_clauses( array $settings, array $clauses_default ): void {
		?>
		<h2 class="revela-section-title" style="margin-top:32px;padding-top:16px;border-top:1px solid #dcdcde;">📝 Cláusulas do Contrato</h2>
		<p class="description" style="margin-bottom:16px;">
			Personalize o texto das cláusulas. <strong>Variáveis disponíveis:</strong><br>
			<code>{estudio}</code>, <code>{responsavel}</code>, <code>{contratante}</code>, <code>{cpf}</code>, <code>{cnpj}</code>,
			<code>{email}</code>, <code>{endereco}</code>, <code>{pacote}</code>, <code>{inclui}</code>, <code>{extras}</code>,
			<code>{total}</code>, <code>{entrada}</code>, <code>{saldo}</code>, <code>{entrada_pct}</code>,
			<code>{entrega_dias}</code>, <code>{refund_pct}</code>, <code>{backup_meses}</code>, <code>{nuvem_dias}</code>,
			<code>{taxa_arquivos}</code>, <code>{taxa_pendrive}</code>, <code>{comarca}</code>, <code>{uf}</code>,
			<code>{uf_nome}</code>, <code>{cidade_assin}</code>, <code>{data_evento}</code>, <code>{data_hoje}</code>,
			<code>{horas_cobertura}</code>, <code>{tipo}</code>, <code>{local}</code>, <code>{plano_nome}</code>,
			<code>{num_parcelas}</code>, <code>{valor_parcela}</code>, <code>{endereco_estudio}</code>,
			<code>{site_estudio}</code>, <code>{documento_estudio}</code>, <code>{extras_texto}</code>
		</p>
		<table class="form-table" role="presentation">
			<?php
			foreach ( $clauses_default as $key => $clause ) :
				$label = $clause['title'];
				$value = $settings[ 'clausula_' . $key ] ?? $clause['text'];
				self::field_clause( 'clausula_' . $key, $label, $value );
			endforeach;
			?>
		</table>
		<?php
	}

	private static function field_text( string $key, string $label, array $settings, string $help = '', string $style = '' ): void {
		$value = esc_attr( $settings[ $key ] ?? '' );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
		echo '<td><input type="text" id="' . esc_attr( $key ) . '" name="revela_settings[' . esc_attr( $key ) . ']" value="' . $value . '" class="regular-text" style="' . esc_attr( $style ) . '"';
		if ( $help ) { echo ' aria-describedby="' . esc_attr( $key ) . '-help"'; }
		echo '>';
		if ( $help ) { echo '<p id="' . esc_attr( $key ) . '-help" class="description">' . esc_html( $help ) . '</p>'; }
		echo '</td></tr>';
	}

	private static function field_email( string $key, string $label, array $settings, string $help = '' ): void {
		$value = esc_attr( $settings[ $key ] ?? '' );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
		echo '<td><input type="email" id="' . esc_attr( $key ) . '" name="revela_settings[' . esc_attr( $key ) . ']" value="' . $value . '" class="regular-text"';
		if ( $help ) { echo ' aria-describedby="' . esc_attr( $key ) . '-help"'; }
		echo '>';
		if ( $help ) { echo '<p id="' . esc_attr( $key ) . '-help" class="description">' . esc_html( $help ) . '</p>'; }
		echo '</td></tr>';
	}

	private static function field_textarea( string $key, string $label, array $settings, string $help = '' ): void {
		$value = esc_textarea( $settings[ $key ] ?? '' );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
		echo '<td><textarea id="' . esc_attr( $key ) . '" name="revela_settings[' . esc_attr( $key ) . ']" class="large-text" rows="3" style="width:100%">' . $value . '</textarea>';
		if ( $help ) { echo '<p class="description">' . esc_html( $help ) . '</p>'; }
		echo '</td></tr>';
	}

	private static function field_number( string $key, string $label, array $settings, string $help = '', int $min = 0, int $max = 9999, string $style = '' ): void {
		$value = esc_attr( $settings[ $key ] ?? 0 );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
		echo '<td><input type="number" min="' . $min . '" max="' . $max . '" step="1" id="' . esc_attr( $key ) . '" name="revela_settings[' . esc_attr( $key ) . ']" value="' . $value . '" style="width:120px;' . esc_attr( $style ) . '"';
		if ( $help ) { echo ' aria-describedby="' . esc_attr( $key ) . '-help"'; }
		echo '>';
		if ( $help ) { echo '<p id="' . esc_attr( $key ) . '-help" class="description">' . esc_html( $help ) . '</p>'; }
		echo '</td></tr>';
	}

	private static function field_clause( string $key, string $label, string $value ): void {
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
		echo '<td><textarea id="' . esc_attr( $key ) . '" name="revela_settings[' . esc_attr( $key ) . ']" class="large-text" rows="5" style="width:100%">' . esc_textarea( $value ) . '</textarea>';
		echo '<br><span class="description">Variáveis: {estudio}, {responsavel}, {contratante}, {cpf}, {cnpj}, {email}, {endereco}, {pacote}, {inclui}, {extras}, {total}, {entrada}, {saldo}, {entrada_pct}, {entrega_dias}, {refund_pct}, {backup_meses}, {nuvem_dias}, {taxa_arquivos}, {taxa_pendrive}, {comarca}, {uf}, {uf_nome}, {cidade_assin}, {data_evento}, {data_hoje}, {horas_cobertura}, {tipo}, {local}, {plano_nome}, {num_parcelas}, {valor_parcela}, {endereco_estudio}, {site_estudio}, {documento_estudio}, {extras_texto}</span></td></tr>';
	}
}