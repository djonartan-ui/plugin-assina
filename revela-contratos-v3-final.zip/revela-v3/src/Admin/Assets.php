<?php

namespace Revela\Admin;

final class Assets {

	public static function enqueue_block_assets(): void {
		$version = REVELA_VERSION;

		$js_file = REVELA_DIR . '/build/package-block.js';
		$css_file = REVELA_DIR . '/build/package-block.css';

		if ( file_exists( $js_file ) ) {
			$asset_file = REVELA_DIR . '/build/package-block.asset.php';
			$deps = [ 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-data', 'wp-api-fetch', 'wp-i18n' ];

			if ( file_exists( $asset_file ) ) {
				$asset = include $asset_file;
				$deps = array_merge( $deps, $asset['dependencies'] ?? [] );
				$version = $asset['version'] ?? $version;
			}

			wp_register_script(
				'revela-package-block',
				REVELA_URL . 'build/package-block.js',
				$deps,
				$version,
				true
			);

			wp_register_style(
				'revela-package-block-editor',
				REVELA_URL . 'build/package-block.css',
				[ 'wp-edit-blocks' ],
				$version
			);

			wp_set_script_translations( 'revela-package-block', 'revela-contratos' );
		}

		$js_file2 = REVELA_DIR . '/build/proposal-block.js';
		$css_file2 = REVELA_DIR . '/build/proposal-block.css';

		if ( file_exists( $js_file2 ) ) {
			$asset_file2 = REVELA_DIR . '/build/proposal-block.asset.php';
			$deps2 = [ 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-data', 'wp-api-fetch', 'wp-i18n' ];

			if ( file_exists( $asset_file2 ) ) {
				$asset2 = include $asset_file2;
				$deps2 = array_merge( $deps2, $asset2['dependencies'] ?? [] );
				$version2 = $asset2['version'] ?? $version;
			} else {
				$version2 = $version;
			}

			wp_register_script(
				'revela-proposal-block',
				REVELA_URL . 'build/proposal-block.js',
				$deps2,
				$version2,
				true
			);

			wp_register_style(
				'revela-proposal-block-editor',
				REVELA_URL . 'build/proposal-block.css',
				[ 'wp-edit-blocks' ],
				$version2
			);

			wp_set_script_translations( 'revela-proposal-block', 'revela-contratos' );
		}
	}

	public static function enqueue_frontend_assets(): void {
		$version = REVELA_VERSION;

		$js_file = REVELA_DIR . '/build/client-form.js';
		$css_file = REVELA_DIR . '/build/client-form.css';

		if ( file_exists( $js_file ) ) {
			$asset_file = REVELA_DIR . '/build/client-form.asset.php';
			$deps = [ 'wp-element', 'wp-api-fetch', 'wp-i18n' ];

			if ( file_exists( $asset_file ) ) {
				$asset = include $asset_file;
				$deps = array_merge( $deps, $asset['dependencies'] ?? [] );
				$version = $asset['version'] ?? $version;
			}

			wp_register_script(
				'revela-client-form',
				REVELA_URL . 'build/client-form.js',
				$deps,
				$version,
				true
			);

			wp_register_style(
				'revela-client-form',
				REVELA_URL . 'build/client-form.css',
				[],
				$version
			);

			wp_localize_script( 'revela-client-form', 'revelaClient', [
				'restUrl' => rest_url( 'revela/v3/' ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'version' => REVELA_VERSION,
			] );

			wp_enqueue_script( 'revela-client-form' );
			wp_enqueue_style( 'revela-client-form' );
		}
	}
}