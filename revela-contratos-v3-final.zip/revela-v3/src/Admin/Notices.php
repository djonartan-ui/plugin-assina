<?php

namespace Revela\Admin;

final class Notices {

	public static function register(): void {
		add_action( 'admin_notices', [ self::class, 'render_notices' ] );
	}

	public static function render_notices(): void {
		if ( is_admin() && current_user_can( 'edit_posts' ) ) {
			$build_dir = REVELA_DIR . '/build';
			if ( ! file_exists( $build_dir . '/package-block.js' ) ) {
				self::render_build_notice();
			}
		}

		if ( is_admin() && current_user_can( 'edit_posts' ) ) {
			$expired_count = self::count_expired_proposals();
			if ( $expired_count > 0 ) {
				self::render_expired_notice( $expired_count );
			}
		}
	}

	private static function render_build_notice(): void {
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, [ 'edit-revela_package', 'revela_package', 'revela-settings' ] ) ) {
			return;
		}
		?>
		<div class="notice notice-warning is-dismissible" data-notice="revela-build">
			<p><strong>REVELA Contratos:</strong> Assets de build não encontrados. Os blocos Gutenberg funcionarão em modo limitado.</p>
			<p>
				<a href="#" class="button button-primary revela-run-build" data-nonce="<?php echo wp_create_nonce( 'revela_build' ); ?>">Executar Build (npm run build)</a>
				<a href="https://github.com/WordPress/gutenberg/tree/trunk/packages/scripts" target="_blank" class="button button-secondary">Saiba mais sobre @wordpress/scripts</a>
			</p>
		</div>
		<script>
			jQuery(document).on('click', '.revela-run-build', function(e) {
				e.preventDefault();
				var $btn = jQuery(this);
				$btn.prop('disabled', true).text('Build requer terminal...');
				alert('Execute "npm run build" no terminal do plugin:\n\ncd wp-content/plugins/revela-contratos\nnpm install\nnpm run build');
				$btn.prop('disabled', false).text('Executar Build (npm run build)');
			});
		</script>
		<?php
	}

	private static function count_expired_proposals(): int {
		$expired = get_posts( [
			'post_type'      => \Revela\Models\Proposal::POST_TYPE,
			'numberposts'    => -1,
			'post_status'    => 'publish',
			'meta_query'     => [
				'relation' => 'AND',
				[
					'key'     => '_revela_status',
					'value'   => 'pending',
					'compare' => '=',
				],
				[
					'key'     => '_revela_expires_at',
					'value'   => current_time( 'mysql' ),
					'compare' => '<',
					'type'    => 'DATETIME',
				],
			],
			'fields'         => 'ids',
		] );
		return count( $expired );
	}

	private static function render_expired_notice( int $count ): void {
		$screen = get_current_screen();
		if ( ! $screen || $screen->id !== 'edit-revela_proposal' ) {
			return;
		}
		?>
		<div class="notice notice-info is-dismissible" data-notice="revela-expired">
			<p><strong>REVELA Contratos:</strong> Existem <?php echo $count; ?> proposta(s) expirada(s) aguardando limpeza.</p>
			<p>
				<a href="<?php echo admin_url( 'admin-post.php?action=revela_cleanup_expired' ); ?>" class="button button-primary">Limpar agora</a>
			</p>
		</div>
		<?php
	}
}