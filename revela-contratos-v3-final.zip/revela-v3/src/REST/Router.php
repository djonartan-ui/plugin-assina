<?php

namespace Revela\REST;

use Revela\Services\SecurityService;
use Revela\Services\ContractService;
use Revela\Services\EmailService;
use Revela\Models\Package;
use Revela\Models\Proposal;

final class Router {

	public static function register(): void {
		add_action( 'rest_api_init', [ self::class, 'register_public_routes' ] );
		add_action( 'rest_api_init', [ self::class, 'register_admin_routes' ] );
	}

	public static function register_public_routes(): void {
		$namespace = 'revela/v3';

		register_rest_route( $namespace, '/proposta/(?P<token>[a-f0-9]{32})', [
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_proposal' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'token' => [
						'validate_callback' => fn( $param ) => preg_match( '/^[a-f0-9]{32}$/', $param ),
					],
				],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ self::class, 'submit_proposal' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'token' => [
						'validate_callback' => fn( $param ) => preg_match( '/^[a-f0-9]{32}$/', $param ),
					],
				],
			],
		] );

		register_rest_route( $namespace, '/proposta/(?P<token>[a-f0-9]{32})/contrato', [
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_contract' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'token' => [
						'validate_callback' => fn( $param ) => preg_match( '/^[a-f0-9]{32}$/', $param ),
					],
				],
			],
		] );

		register_rest_route( $namespace, '/health', [
			[
				'methods'             => 'GET',
				'callback'            => fn() => [ 'status' => 'ok', 'version' => REVELA_VERSION ],
				'permission_callback' => '__return_true',
			],
		] );
	}

	public static function register_admin_routes(): void {
		$namespace = 'revela/v3';

		register_rest_route( $namespace, '/packages', [
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'list_packages' ],
				'permission_callback' => [ self::class, 'check_admin' ],
			],
		] );

		register_rest_route( $namespace, '/propostas', [
			[
				'methods'             => 'POST',
				'callback'            => [ self::class, 'create_proposal' ],
				'permission_callback' => [ self::class, 'check_admin' ],
				'args'                => [
					'package_id'      => [ 'required' => true, 'validate_callback' => 'is_numeric' ],
					'client_name'     => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
					'client_email'    => [ 'sanitize_callback' => 'sanitize_email' ],
					'event_date'      => [ 'sanitize_callback' => 'sanitize_text_field' ],
					'extras'          => [ 'default' => [], 'sanitize_callback' => fn($v) => array_map( 'intval', (array) $v ) ],
					'selected_plan'   => [ 'sanitize_callback' => 'sanitize_text_field' ],
					'delivery_days'   => [ 'default' => 60, 'validate_callback' => 'is_numeric' ],
					'client_cnpj'     => [ 'sanitize_callback' => 'sanitize_text_field' ],
					'extra_clauses'   => [ 'sanitize_callback' => 'wp_kses_post' ],
				],
			],
		] );

		register_rest_route( $namespace, '/propostas/(?P<id>\d+)', [
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_proposal_admin' ],
				'permission_callback' => [ self::class, 'check_admin' ],
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ self::class, 'delete_proposal' ],
				'permission_callback' => [ self::class, 'check_admin' ],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ self::class, 'reset_client_data' ],
				'permission_callback' => [ self::class, 'check_admin' ],
			],
		] );

		register_rest_route( $namespace, '/settings', [
			[
				'methods'             => 'GET',
				'callback'            => [ self::class, 'get_settings' ],
				'permission_callback' => [ self::class, 'check_admin' ],
			],
			[
				'methods'             => 'POST',
				'callback'            => [ self::class, 'update_settings' ],
				'permission_callback' => [ self::class, 'check_admin' ],
			],
		] );
	}

	public static function check_admin( \WP_REST_Request $request ): bool {
		return is_user_logged_in() && current_user_can( 'edit_posts' );
	}

	public static function get_proposal( \WP_REST_Request $request ): \WP_REST_Response {
		$token = $request->get_param( 'token' );
		$proposal = Proposal::find_by_token( $token );

		if ( ! $proposal ) {
			return new \WP_REST_Response( [ 'error' => 'Proposta não encontrada' ], 404 );
		}

		$ctx = ContractService::instance()->build_context( $proposal->ID );

		if ( ! $ctx ) {
			return new \WP_REST_Response( [ 'error' => 'Erro ao carregar proposta' ], 500 );
		}

		return rest_ensure_response( self::format_proposal_for_client( $ctx ) );
	}

	public static function submit_proposal( \WP_REST_Request $request ): \WP_REST_Response {
		$token = $request->get_param( 'token' );
		$proposal = Proposal::find_by_token( $token );

		if ( ! $proposal ) {
			return new \WP_REST_Response( [ 'error' => 'Proposta não encontrada' ], 404 );
		}

		$ctx = ContractService::instance()->build_context( $proposal->ID );
		if ( $ctx && $ctx->status === 'completed' ) {
			return new \WP_REST_Response( [ 'error' => 'Proposta já preenchida' ], 400 );
		}

		$required = [ 'nome', 'cpf', 'email', 'endereco', 'aceite_valores', 'aceite_clausulas' ];
		foreach ( $required as $field ) {
			if ( empty( $request->get_param( $field ) ) ) {
				return new \WP_REST_Response( [ 'error' => "Campo obrigatório: $field" ], 400 );
			}
		}

		$security = SecurityService::instance();

		$cpf = sanitize_text_field( $request->get_param( 'cpf' ) );
		if ( ! $security->validate_cpf( $cpf ) ) {
			return new \WP_REST_Response( [ 'error' => 'CPF inválido' ], 400 );
		}

		$cnpj = sanitize_text_field( $request->get_param( 'cnpj' ) );
		if ( $cnpj && ! $security->validate_cnpj( $cnpj ) ) {
			return new \WP_REST_Response( [ 'error' => 'CNPJ inválido' ], 400 );
		}

		$client_data = [
			'nome'      => sanitize_text_field( $request->get_param( 'nome' ) ),
			'cpf'       => $cpf,
			'email'     => sanitize_email( $request->get_param( 'email' ) ),
			'endereco'  => sanitize_textarea_field( $request->get_param( 'endereco' ) ),
		];

		$locals = [];
		$local_fields = [ 'local_colacao', 'local_festa', 'local_prep_noiva', 'local_prep_noivo', 'local_cerimonia', 'local_sessao' ];
		foreach ( $local_fields as $field ) {
			$val = $request->get_param( $field );
			if ( $val ) {
				$locals[ $field ] = sanitize_textarea_field( $val );
			}
		}

		$entry_value = (float) $request->get_param( 'entry_value' );

		$acceptance = [
			'ts'   => current_time( 'timestamp' ),
			'data' => current_time( 'd/m/Y H:i' ),
			'ip'   => sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' ),
			'nome' => $client_data['nome'],
		];

		Proposal::set_meta( $proposal->ID, 'client_data', $client_data );
		Proposal::set_meta( $proposal->ID, 'client_locals', $locals );
		Proposal::set_meta( $proposal->ID, 'entry_value', $entry_value );
		Proposal::set_meta( $proposal->ID, 'acceptance', $acceptance );
		Proposal::set_meta( $proposal->ID, 'status', 'completed' );

		EmailService::instance()->send_proposal_emails( $proposal->ID );

		return rest_ensure_response( [
			'success'      => true,
			'message'      => 'Dados enviados com sucesso!',
			'contract_url' => add_query_arg( 'revela_token', $token, home_url( '/proposta/' ) ) . '?view=contrato',
		] );
	}

	public static function get_contract( \WP_REST_Request $request ): \WP_REST_Response {
		$token = $request->get_param( 'token' );
		$proposal = Proposal::find_by_token( $token );

		if ( ! $proposal ) {
			status_header( 404 );
			return new \WP_REST_Response( '<h1>Proposta não encontrada</h1>', 404, [ 'Content-Type' => 'text/html; charset=utf-8' ] );
		}

		$html = ContractService::instance()->render_contract_html( $proposal->ID );

		return new \WP_REST_Response( $html, 200, [ 'Content-Type' => 'text/html; charset=utf-8' ] );
	}

	public static function list_packages( \WP_REST_Request $request ): \WP_REST_Response {
		$posts = get_posts( [
			'post_type'      => Package::POST_TYPE,
			'numberposts'    => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'post_status'    => 'publish',
		] );

		$data = array_map( [ Package::class, 'get_rest_data' ], array_column( $posts, 'ID' ) );
		return rest_ensure_response( $data );
	}

	public static function create_proposal( \WP_REST_Request $request ): \WP_REST_Response {
		$package_id = (int) $request->get_param( 'package_id' );
		$client_name = sanitize_text_field( $request->get_param( 'client_name' ) );
		$client_email = sanitize_email( $request->get_param( 'client_email' ) );
		$event_date = sanitize_text_field( $request->get_param( 'event_date' ) );
		$extras = array_map( 'intval', (array) $request->get_param( 'extras' ) );
		$selected_plan = sanitize_text_field( $request->get_param( 'selected_plan' ) );
		$delivery_days = (int) $request->get_param( 'delivery_days' );
		$client_cnpj = sanitize_text_field( $request->get_param( 'client_cnpj' ) );
		$extra_clauses = wp_kses_post( wp_unslash( $request->get_param( 'extra_clauses' ) ) );

		if ( ! $package_id || ! $client_name ) {
			return new \WP_REST_Response( [ 'error' => 'Pacote e nome do cliente são obrigatórios' ], 400 );
		}

		$proposal_id = wp_insert_post( [
			'post_type'   => Proposal::POST_TYPE,
			'post_status' => 'publish',
			'post_title'  => $client_name,
		] );

		if ( is_wp_error( $proposal_id ) ) {
			return new \WP_REST_Response( [ 'error' => 'Erro ao criar proposta' ], 500 );
		}

		$token = Proposal::generate_token();
		$expires_at = gmdate( 'Y-m-d H:i:s', strtotime( '+15 days' ) );

		Proposal::set_meta( $proposal_id, 'package_id', $package_id );
		Proposal::set_meta( $proposal_id, 'extras', $extras );
		Proposal::set_meta( $proposal_id, 'client_email', $client_email );
		Proposal::set_meta( $proposal_id, 'event_date', $event_date );
		Proposal::set_meta( $proposal_id, 'delivery_days', $delivery_days );
		Proposal::set_meta( $proposal_id, 'client_cnpj', $client_cnpj );
		Proposal::set_meta( $proposal_id, 'selected_plan', $selected_plan );
		Proposal::set_meta( $proposal_id, 'extra_clauses', $extra_clauses );
		Proposal::set_meta( $proposal_id, 'token', $token );
		Proposal::set_meta( $proposal_id, 'status', 'pending' );
		Proposal::set_meta( $proposal_id, 'created_at', current_time( 'mysql' ) );
		Proposal::set_meta( $proposal_id, 'expires_at', $expires_at );

		$url = add_query_arg( 'revela_token', $token, home_url( '/proposta/' ) );

		return rest_ensure_response( [
			'id'        => $proposal_id,
			'token'     => $token,
			'url'       => $url,
			'whatsapp'  => 'https://wa.me/?text=' . rawurlencode( "Olá! Preparei sua proposta. É só preencher seus dados por aqui: $url" ),
		] );
	}

	public static function get_proposal_admin( \WP_REST_Request $request ): \WP_REST_Response {
		$id = (int) $request->get_param( 'id' );
		$proposal = get_post( $id );

		if ( ! $proposal || $proposal->post_type !== Proposal::POST_TYPE ) {
			return new \WP_REST_Response( [ 'error' => 'Proposta não encontrada' ], 404 );
		}

		$ctx = ContractService::instance()->build_context( $id );

		return rest_ensure_response( [
			'id'         => $id,
			'title'      => $proposal->post_title,
			'status'     => $ctx?->status ?? 'unknown',
			'token'      => $ctx?->token ?? '',
			'url'        => $ctx ? add_query_arg( 'revela_token', $ctx->token, home_url( '/proposta/' ) ) : '',
			'package'    => $ctx ? [
				'id'    => $ctx->package_id,
				'title' => $ctx->package_title,
			] : null,
			'client'     => $ctx ? [
				'nome'  => $ctx->client_name,
				'email' => $ctx->client_email,
			] : null,
			'acceptance' => $ctx?->acceptance ?? [],
		] );
	}

	public static function delete_proposal( \WP_REST_Request $request ): \WP_REST_Response {
		$id = (int) $request->get_param( 'id' );
		wp_delete_post( $id, true );
		return rest_ensure_response( [ 'success' => true ] );
	}

	public static function reset_client_data( \WP_REST_Request $request ): \WP_REST_Response {
		$id = (int) $request->get_param( 'id' );
		$proposal = get_post( $id );

		if ( ! $proposal || $proposal->post_type !== Proposal::POST_TYPE ) {
			return new \WP_REST_Response( [ 'error' => 'Proposta não encontrada' ], 404 );
		}

		Proposal::delete_meta( $id, 'client_data' );
		Proposal::delete_meta( $id, 'client_locals' );
		Proposal::delete_meta( $id, 'entry_value' );
		Proposal::delete_meta( $id, 'acceptance' );
		Proposal::set_meta( $id, 'status', 'pending' );

		return rest_ensure_response( [ 'success' => true, 'message' => 'Dados do cliente resetados. Status voltou para "pendente".' ] );
	}

	public static function get_settings( \WP_REST_Request $request ): \WP_REST_Response {
		return rest_ensure_response( SettingsService::instance()->get_all() );
	}

	public static function update_settings( \WP_REST_Request $request ): \WP_REST_Response {
		$data = $request->get_json_params();
		if ( ! is_array( $data ) ) {
			return new \WP_REST_Response( [ 'error' => 'Dados inválidos' ], 400 );
		}

		$settings = SettingsService::instance()->update( $data );
		$errors = ( new \Revela\Validators\SettingsValidator() )->validate( $settings );

		if ( ! empty( $errors ) ) {
			return new \WP_REST_Response( [ 'errors' => $errors ], 400 );
		}

		return rest_ensure_response( $settings );
	}

	private static function format_proposal_for_client( \Revela\DTO\ProposalData $ctx ): array {
		return [
			'id'              => $ctx->proposal_id,
			'title'           => $ctx->package_title,
			'status'          => $ctx->status,
			'package'         => [
				'id'          => $ctx->package_id,
				'nome'        => $ctx->package_title,
				'valor'       => $ctx->package_price,
				'horas'       => $ctx->package_hours,
				'inclui'      => $ctx->package_includes,
				'categoria'   => $ctx->package_category,
				'payment_plans' => $ctx->payment_plans,
			],
			'extras'          => $ctx->extras,
			'total'           => $ctx->package_price + array_sum( array_column( $ctx->extras, 'preco' ) ),
			'entrada'         => $ctx->entry_value > 0 ? $ctx->entry_value : $ctx->package_price * 0.3,
			'saldo'           => ( $ctx->package_price + array_sum( array_column( $ctx->extras, 'preco' ) ) ) - ( $ctx->entry_value > 0 ? $ctx->entry_value : $ctx->package_price * 0.3 ),
			'entrada_pct'     => $ctx->selected_plan ? ( $ctx->payment_plans[0]['entrada_pct'] ?? 30 ) : 30,
			'num_parcelas'    => $ctx->selected_plan ? ( $ctx->payment_plans[0]['num_parcelas'] ?? 0 ) : 0,
			'valor_parcela'   => 0,
			'plan_name'       => $ctx->selected_plan,
			'event_date'      => $ctx->event_date,
			'event_date_ext'  => $ctx->event_date_ext,
			'entrega_dias'    => $ctx->delivery_days,
			'clauses'         => ContractService::instance()->build_clauses( $ctx ),
			'settings'        => [
				'estudio'      => $ctx->settings['estudio'] ?? '',
				'responsavel'  => $ctx->settings['responsavel'] ?? '',
				'comarca'      => $ctx->settings['comarca'] ?? '',
				'uf'           => $ctx->settings['uf'] ?? '',
				'cidade_assin' => $ctx->settings['cidade_assin'] ?? '',
			],
		];
	}
}