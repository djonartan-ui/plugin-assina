<?php

namespace Revela\Validators;

final class SettingsValidator {

	private array $sanitizers = [];

	public function __construct() {
		$this->sanitizers = [
			'text'        => fn( $v ) => sanitize_text_field( $v ),
			'email'       => fn( $v ) => sanitize_email( $v ),
			'textarea'    => fn( $v ) => wp_kses_post( wp_unslash( $v ) ),
			'textarea_raw'=> fn( $v ) => wp_unslash( $v ),
			'url'         => fn( $v ) => esc_url_raw( $v ),
			'int'         => fn( $v ) => max( 0, (int) $v ),
			'float'       => fn( $v ) => max( 0.0, (float) $v ),
			'uf'          => fn( $v ) => strtoupper( substr( sanitize_text_field( $v ), 0, 2 ) ),
			'clause'      => fn( $v ) => wp_kses_post( wp_unslash( $v ) ),
		];
	}

	public function sanitize( array $input, array $current ): array {
		$defaults = \Revela\Services\SettingsService::get_defaults();
		$out = [];

		foreach ( [ 'estudio', 'responsavel', 'contato', 'documento', 'comarca', 'cidade_assin', 'site_estudio', 'endereco_estudio' ] as $key ) {
			$out[ $key ] = $this->sanitizers['text']( $input[ $key ] ?? $current[ $key ] ?? $defaults[ $key ] );
		}

		$out['email_estudio'] = $this->sanitizers['email']( $input['email_estudio'] ?? $current['email_estudio'] ?? $defaults['email_estudio'] );
		$out['uf']            = $this->sanitizers['uf']( $input['uf'] ?? $current['uf'] ?? $defaults['uf'] );
		$out['endereco_estudio'] = $this->sanitizers['textarea']( $input['endereco_estudio'] ?? $current['endereco_estudio'] ?? $defaults['endereco_estudio'] );

		foreach ( [ 'entrada_pct', 'validade_dias', 'entrega_dias', 'refund_pct', 'backup_meses', 'nuvem_dias', 'taxa_arquivos', 'taxa_pendrive', 'nonce_lifetime', 'max_file_size' ] as $key ) {
			$out[ $key ] = $this->sanitizers['int']( $input[ $key ] ?? $current[ $key ] ?? $defaults[ $key ] );
		}

		foreach ( \Revela\Services\SettingsService::get_default_clauses() as $key => $clause ) {
			$field = 'clausula_' . $key;
			$out[ $field ] = $this->sanitizers['clause']( $input[ $field ] ?? $current[ $field ] ?? $clause['text'] );
		}

		return $out;
	}

	public function validate( array $data ): array {
		$errors = [];

		if ( ! is_email( $data['email_estudio'] ?? '' ) ) {
			$errors[] = 'E-mail do estúdio inválido';
		}

		if ( strlen( $data['uf'] ?? '' ) !== 2 ) {
			$errors[] = 'UF deve ter 2 caracteres';
		}

		if ( ( $data['entrada_pct'] ?? 0 ) > 100 ) {
			$errors[] = 'Porcentagem de entrada não pode exceder 100%';
		}

		if ( ( $data['refund_pct'] ?? 0 ) > 100 ) {
			$errors[] = 'Porcentagem de reembolso não pode exceder 100%';
		}

		return $errors;
	}
}