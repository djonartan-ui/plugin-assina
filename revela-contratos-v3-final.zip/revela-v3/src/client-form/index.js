import { createElement } from '@wordpress/element';
import { createRoot } from 'react-dom/client';
import { __ } from '@wordpress/i18n';
import { Button, TextControl, TextareaControl, CheckboxControl, Notice, Spinner, FormTokenField } from '@wordpress/components';
import { useState, useEffect, useCallback } from '@wordpress/element';
import { apiFetch } from '@wordpress/api-fetch';
import './style.css';

function formatBRL( val ) {
	if ( val === undefined || val === null ) return 'R$ 0,00';
	return 'R$ ' + Number( val ).toLocaleString( 'pt-BR', { minimumFractionDigits: 2 } );
}

function formatDateExtenso( iso ) {
	if ( ! iso ) return '';
	const p = iso.split( '-' );
	if ( p.length !== 3 ) return iso;
	const meses = [ '', 'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro' ];
	return `${parseInt( p[2], 10 )} de ${meses[ parseInt( p[1], 10 ) ]} de ${p[0]}`;
}

function ClientFormApp() {
	const [data, setData] = useState( null );
	const [loading, setLoading] = useState( true );
	const [submitting, setSubmitting ] = useState( false );
	const [error, setError ] = useState( null );
	const [formData, setFormData ] = useState( {
		nome: '',
		cpf: '',
		email: '',
		endereco: '',
		local_colacao: '',
		local_festa: '',
		local_prep_noiva: '',
		local_prep_noivo: '',
		local_cerimonia: '',
		local_sessao: '',
		entry_value: '',
		aceite_valores: false,
		aceite_clausulas: false,
	} );
	const [preview, setPreview ] = useState( { entrada: 0, saldo: 0, parcela: 0 } );

	const container = document.getElementById( 'revela-client-app' );
	const token = container?.dataset.token || '';
	const apiUrl = container?.dataset.apiUrl || '';

	// Load proposal data
	useEffect( () => {
		if ( ! token ) return;
		apiFetch( { path: `revela/v3/proposta/${token}` } )
			.then( setData )
			.catch( err => setError( err.message || 'Erro ao carregar proposta' ) )
			.finally( () => setLoading( false ) );
	}, [ token ]);

	// Update preview when entry_value changes
	useEffect( () => {
		if ( ! data ) return;
		const total = data.total || 0;
		const meses = data.num_parcelas || 0;
		const entrada = parseFloat( formData.entry_value ) || 0;
		const entradaFinal = Math.min( entrada, total );
		const saldo = total - entradaFinal;
		const parcela = meses > 0 && saldo > 0 ? saldo / meses : 0;
		setPreview( { entrada: entradaFinal, saldo, parcela } );
	}, [ formData.entry_value, data ]);

	const handleChange = useCallback( ( field, value ) => {
		setFormData( prev => ( { ...prev, [ field ]: value } ) );
	}, [] );

	const handleSubmit = useCallback( async ( e ) => {
		e.preventDefault();
		setError( null );

		if ( ! formData.nome || ! formData.cpf || ! formData.email || ! formData.endereco ) {
			setError( 'Preencha todos os campos obrigatórios' );
			return;
		}
		if ( ! formData.aceite_valores || ! formData.aceite_clausulas ) {
			setError( 'Você deve concordar com os valores e as cláusulas' );
			return;
		}

		setSubmitting( true );

		try {
			const params = new URLSearchParams();
			params.append( 'nome', formData.nome );
			params.append( 'cpf', formData.cpf );
			params.append( 'email', formData.email );
			params.append( 'endereco', formData.endereco );
			params.append( 'local_colacao', formData.local_colacao );
			params.append( 'local_festa', formData.local_festa );
			params.append( 'local_prep_noiva', formData.local_prep_noiva );
			params.append( 'local_prep_noivo', formData.local_prep_noivo );
			params.append( 'local_cerimonia', formData.local_cerimonia );
			params.append( 'local_sessao', formData.local_sessao );
			params.append( 'entry_value', formData.entry_value );
			params.append( 'aceite_valores', formData.aceite_valores ? '1' : '0' );
			params.append( 'aceite_clausulas', formData.aceite_clausulas ? '1' : '0' );

			const res = await apiFetch( {
				path: `revela/v3/proposta/${token}`,
				method: 'POST',
				data: Object.fromEntries( params ),
			} );

			if ( res.success ) {
				window.location.href = res.contract_url;
			} else {
				setError( res.message || 'Erro ao enviar' );
			}
		} catch ( err ) {
			setError( err.message || 'Erro ao enviar dados' );
		} finally {
			setSubmitting( false );
		}
	}, [ formData, token ]);

	if ( loading ) {
		return createElement( 'div', { className: 'revela-loading' },
			createElement( Spinner ),
			' Carregando proposta...'
		);
	}

	if ( error ) {
		return createElement( Notice, { status: 'error', isDismissible: false }, error );
	}

	if ( ! data ) {
		return createElement( Notice, { status: 'error', isDismissible: false }, 'Proposta não encontrada' );
	}

	if ( data.status === 'completed' ) {
		return createElement( 'div', { className: 'revela-completed' },
			createElement( Notice, { status: 'success' }, 'Esta proposta já foi preenchida.' ),
			createElement( 'a', { href: `${apiUrl.replace('/revela/v3/', '')}proposta/${token}/contrato`, className: 'button button-primary', target: '_blank' }, 'Ver Contrato' )
		);
	}

	const pkg = data.package || {};
	const planName = data.plan_name || '';

	return createElement( 'form', { onSubmit: handleSubmit, className: 'revela-client-form', noValidate: true },
		// Banner
		createElement( 'div', { className: 'revela-banner' },
			createElement( 'div', { className: 'revela-banner-studio' }, data.settings?.estudio || 'REVELA' ),
			createElement( 'div', { className: 'revela-banner-title' },
				createElement( 'span', null, data.title ),
				data.event_date_ext && createElement( 'span', { className: 'revela-banner-date' }, ` — ${data.event_date_ext}` ),
				' ',
				createElement( 'span', null, pkg.nome ? `— ${pkg.nome}` : '' )
			),
			createElement( 'div', { className: 'revela-banner-category' }, pkg.categoria ? pkg.categoria.charAt(0).toUpperCase() + pkg.categoria.slice(1) : '' )
		),

		// Review section
		createElement( 'section', { className: 'revela-review' },
			createElement( 'h2', null, 'Revise sua proposta' ),
			createElement( 'table', { className: 'revela-detail' },
				createElement( 'tbody', null,
					data.event_date_ext && createElement( 'tr', null, createElement( 'td', null, 'Data do evento' ), createElement( 'td', null, data.event_date_ext ) ),
					createElement( 'tr', null, createElement( 'td', null, 'Pacote' ), createElement( 'td', null, pkg.nome ) ),
					pkg.horas && createElement( 'tr', null, createElement( 'td', null, 'Horas de cobertura' ), createElement( 'td', null, `${pkg.horas}h` ) ),
					pkg.inclui && createElement( 'tr', null, createElement( 'td', { style: { verticalAlign: 'top' } }, 'Inclui' ), createElement( 'td', { style: { textAlign: 'left', whiteSpace: 'pre-wrap' } }, pkg.inclui ) ),
					data.extras?.map( ( ex, i ) => createElement( 'tr', { key: i }, createElement( 'td', null, 'Extra' ), createElement( 'td', null, `${ex.nome} — ${formatBRL( ex.preco )}` ) ) ),
					planName && createElement( 'tr', null, createElement( 'td', null, 'Plano escolhido' ), createElement( 'td', null, planName ) ),
					data.num_parcelas === 0 ? (
						<>
							<tr><td>Entrada ({data.entrada_pct}%)</td><td>{formatBRL( data.entrada )}</td></tr>
						</>
					) : data.num_parcelas > 0 ? (
						<>
							<tr><td>Entrada ({data.entrada_pct}%)</td><td>{formatBRL( data.entrada )}</td></tr>
							<tr><td>Saldo parcelado</td><td>{data.num_parcelas}× de {formatBRL( data.valor_parcela )}</td></tr>
						</>
					) : (
						<>
							<tr><td>Entrada</td><td>{formatBRL( data.entrada )}</td></tr>
							<tr><td>Saldo</td><td>{formatBRL( data.saldo )}</td></tr>
						</>
					),
					createElement( 'tr', { className: 'revela-total' }, createElement( 'td', null, 'Investimento total' ), createElement( 'td', null, formatBRL( data.total ) ) ),
					createElement( 'tr', null, createElement( 'td', null, 'Prazo de entrega' ), createElement( 'td', null, `até ${data.entrega_dias} dias após o evento` ) )
				)
			),

			// Clauses accordion
			createElement( 'details', { className: 'revela-clauses' },
				createElement( 'summary', null, 'Ver cláusulas do contrato' ),
				data.clauses?.map( ( cl, i ) => createElement( 'div', { key: i, className: 'revela-clause' },
					createElement( 'b', null, `Cláusula ${i + 1} — ${cl.title}` ),
					createElement( 'span', null, cl.text )
				) )
			)
		),

		// Client data form
		createElement( 'div', { className: 'revela-form-section' },
			createElement( 'h2', null, 'Seus dados' ),
			createElement( 'p', { className: 'revela-sub' }, 'Preencha para gerarmos seu contrato. Leva 2 minutos.' ),

			createElement( 'div', { className: 'revela-field-group' },
				createElement( 'label', null, 'Nome completo *' ),
				createElement( TextControl, {
					value: formData.nome,
					onChange: v => handleChange( 'nome', v ),
					required: true,
					placeholder: 'Seu nome completo',
				} )
			),

			createElement( 'div', { className: 'revela-field-group' },
				createElement( 'label', null, 'CPF *' ),
				createElement( TextControl, {
					value: formData.cpf,
					onChange: v => handleChange( 'cpf', v ),
					required: true,
					placeholder: '000.000.000-00',
					inputMode: 'numeric',
				} )
			),

			createElement( 'div', { className: 'revela-field-group' },
				createElement( 'label', null, 'E-mail *' ),
				createElement( TextControl, {
					value: formData.email,
					onChange: v => handleChange( 'email', v ),
					type: 'email',
					required: true,
					placeholder: 'voce@email.com',
				} )
			),

			createElement( 'div', { className: 'revela-field-group' },
				createElement( 'label', null, 'Endereço completo *' ),
				createElement( TextareaControl, {
					value: formData.endereco,
					onChange: v => handleChange( 'endereco', v ),
					placeholder: 'Rua, número, bairro, cidade, CEP',
					rows: 3,
				} )
			),

			// Event location
			createElement( 'div', { className: 'revela-field-group' },
				createElement( 'label', null, 'Endereço do evento *' ),
				createElement( TextareaControl, {
					value: formData.local_colacao,
					onChange: v => handleChange( 'local_colacao', v ),
					placeholder: 'Endereço completo do evento',
					rows: 2,
				} )
			),

			// Payment plan preview
			createElement( 'div', { className: 'revela-payment-section' },
				createElement( 'h3', null, 'Pagamento' ),
				planName && createElement( 'div', { className: 'revela-selected-plan' },
					createElement( 'strong', null, `Plano: ${planName}` ),
					createElement( 'br' ),
					data.num_parcelas === 0 ? (
						createElement( 'span', { className: 'revela-avista' }, `À vista — Entrada ${data.entrada_pct}% (${formatBRL( data.entrada )})` )
					) : (
						<>Entrada {data.entrada_pct}% + {data.num_parcelas}× de {formatBRL( data.valor_parcela )}</>
					)
				),

				createElement( 'div', { className: 'revela-field-group' },
					createElement( 'label', null, 'Valor de entrada (opcional)' ),
					createElement( TextControl, {
						value: formData.entry_value,
						onChange: v => handleChange( 'entry_value', v ),
						type: 'number',
						step: '0.01',
						min: '0',
						max: data.total,
						placeholder: `Ex: ${formatBRL( data.total * 0.3 )}`,
						inputMode: 'decimal',
					} ),
					createElement( 'p', { className: 'revela-help' }, 'Deixe em branco para usar o valor padrão do plano. O saldo será recalculado automaticamente.' )
				),

				( preview.entrada > 0 || preview.saldo > 0 ) && createElement( 'div', { className: 'revela-preview' },
					createElement( 'strong', null, 'Simulação:' ),
					createElement( 'br' ),
					createElement( 'span', null, `Entrada: ${formatBRL( preview.entrada )}` ),
					createElement( 'br' ),
					createElement( 'span', null, `Saldo: ${formatBRL( preview.saldo )}` ),
					data.num_parcelas > 0 && createElement( 'span', null, `${data.num_parcelas} parcelas de: ${formatBRL( preview.parcela )} cada` )
				)
			),

			// Agreements
			createElement( 'div', { className: 'revela-agreements' },
				createElement( CheckboxControl, {
					label: createElement( 'span', null, 'Li e ', createElement( 'strong', null, 'concordo com os valores e as condições' ), ' do pacote acima.' ),
					checked: formData.aceite_valores,
					onChange: v => handleChange( 'aceite_valores', v ),
					required: true,
				} ),
				createElement( CheckboxControl, {
					label: createElement( 'span', null, 'Li e ', createElement( 'strong', null, 'aceito as cláusulas do contrato' ), ' apresentadas nesta página.' ),
					checked: formData.aceite_clausulas,
					onChange: v => handleChange( 'aceite_clausulas', v ),
					required: true,
				} )
			),

			createElement( Button, {
				isPrimary: true,
				isLarge: true,
				type: 'submit',
				disabled: submitting,
				className: 'revela-submit-btn',
			}, submitting ? createElement( 'span', null, createElement( Spinner, { size: 'small' } ), ' Enviando...' ) : 'Concordar e enviar' ),

			createElement( 'p', { className: 'revela-mini' }, 'Ao enviar, registramos seu aceite eletrônico (data e horário). Seus dados são usados apenas para este contrato (LGPD).' ),

			error && createElement( Notice, { status: 'error', isDismissible: true, onRemove: () => setError( null ) }, error )
		)
	);
}

// Auto-mount on DOM ready
document.addEventListener( 'DOMContentLoaded', () => {
	const container = document.getElementById( 'revela-client-app' );
	if ( container && ! container.querySelector( '.revela-client-form' ) ) {
		const root = createRoot( container );
		root.render( createElement( ClientFormApp ) );
	}
} );

export default ClientFormApp;