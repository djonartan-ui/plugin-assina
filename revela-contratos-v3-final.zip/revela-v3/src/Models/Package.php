<?php

namespace Revela\Models;

use Revela\Services\SettingsService;

final class Package {

	public const POST_TYPE = 'revela_package';
	public const META_PREFIX = '_revela_';

	private static $categories = [
		'casamento'   => 'Casamento',
		'prewedding'  => 'Pré-wedding',
		'formatura'   => 'Formatura',
		'evento'      => 'Evento',
		'extra'       => 'Extra',
	];

	private static $default_plans = [
		[ 'name' => 'À vista (10% desc.)', 'entrada_pct' => 10, 'num_parcelas' => 0 ],
		[ 'name' => 'Entrada + 6×',        'entrada_pct' => 30, 'num_parcelas' => 6 ],
		[ 'name' => 'Entrada + 10×',       'entrada_pct' => 30, 'num_parcelas' => 10 ],
		[ 'name' => 'Entrada + 12×',       'entrada_pct' => 30, 'num_parcelas' => 12 ],
	];

	public static function register(): void {
		$labels = [
			'name'               => 'Pacotes',
			'singular_name'      => 'Pacote',
			'add_new_item'       => 'Adicionar pacote',
			'edit_item'          => 'Editar pacote',
			'new_item'           => 'Novo pacote',
			'view_item'          => 'Ver pacote',
			'search_items'       => 'Buscar pacotes',
			'not_found'          => 'Nenhum pacote encontrado',
			'not_found_in_trash' => 'Nenhum pacote na lixeira',
			'menu_name'          => 'REVELA',
		];

		register_post_type( self::POST_TYPE, [
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => true,
			'rest_base'           => 'revela-packages',
			'rest_controller_class' => 'WP_REST_Posts_Controller',
			'menu_icon'           => 'dashicons-camera',
			'menu_position'       => 21,
			'supports'            => [ 'title', 'editor', 'custom-fields' ],
			'has_archive'         => false,
			'rewrite'             => false,
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
			'capabilities'        => [
				'edit_post'          => 'edit_posts',
				'read_post'          => 'read_posts',
				'delete_post'        => 'delete_posts',
				'edit_posts'         => 'edit_posts',
				'edit_others_posts'  => 'edit_others_posts',
				'publish_posts'      => 'publish_posts',
				'read_private_posts' => 'read_private_posts',
			],
		] );
	}

	public static function get_categories(): array {
		return self::$categories;
	}

	public static function get_default_plans(): array {
		return self::$default_plans;
	}

	public static function get_payment_plans( int $post_id ): array {
		$plans = get_post_meta( $post_id, self::META_PREFIX . 'payment_plans', true );
		return is_array( $plans ) ? array_values( array_filter( $plans, 'is_array' ) ) : [];
	}

	public static function save_payment_plans( int $post_id, array $plans ): array {
		$clean = [];
		foreach ( $plans as $plan ) {
			$name = sanitize_text_field( $plan['name'] ?? '' );
			if ( $name === '' ) {
				continue;
			}
			$clean[] = [
				'nome'         => $name,
				'entrada_pct'  => max( 0, min( 100, (int) ( $plan['entrada_pct'] ?? 0 ) ) ),
				'num_parcelas' => max( 0, min( 60, (int) ( $plan['num_parcelas'] ?? 0 ) ) ),
			];
		}
		update_post_meta( $post_id, self::META_PREFIX . 'payment_plans', $clean );
		return $clean;
	}

	public static function get_price( int $post_id ): float {
		return (float) get_post_meta( $post_id, self::META_PREFIX . 'preco', true );
	}

	public static function get_hours( int $post_id ): int {
		return (int) get_post_meta( $post_id, self::META_PREFIX . 'horas', true );
	}

	public static function get_includes( int $post_id ): string {
		return get_post_meta( $post_id, self::META_PREFIX . 'inclui', true );
	}

	public static function get_category( int $post_id ): string {
		return get_post_meta( $post_id, self::META_PREFIX . 'categoria', true );
	}

	public static function get_rest_data( int $post_id ): array {
		$price = self::get_price( $post_id );
		$plans = self::get_payment_plans( $post_id );

		foreach ( $plans as &$plan ) {
			$entrada_pct = (int) $plan['entrada_pct'];
			$num_parcelas = (int) $plan['num_parcelas'];
			$entrada_val = $price * $entrada_pct / 100;
			$saldo = $price - $entrada_val;
			$plan['preview'] = [
				'entrada'       => $entrada_val,
				'saldo'         => $saldo,
				'valor_parcela' => $num_parcelas > 0 ? $saldo / $num_parcelas : 0,
			];
		}

		return [
			'id'             => $post_id,
			'title'          => get_the_title( $post_id ),
			'categoria'      => self::get_category( $post_id ),
			'preco'          => $price,
			'horas'          => self::get_hours( $post_id ),
			'inclui'         => self::get_includes( $post_id ),
			'parcelas_texto' => get_post_meta( $post_id, self::META_PREFIX . 'parcelas', true ),
			'payment_plans'  => $plans,
		];
	}
}