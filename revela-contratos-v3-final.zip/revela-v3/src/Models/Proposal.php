<?php

namespace Revela\Models;

final class Proposal {

	public const POST_TYPE = 'revela_proposal';
	public const META_PREFIX = '_revela_';

	private static $statuses = [
		'draft'     => 'Rascunho',
		'pending'   => 'Enviada ao cliente',
		'completed' => 'Preenchida',
		'expired'   => 'Expirada',
	];

	public static function register(): void {
		$labels = [
			'name'               => 'Propostas',
			'singular_name'      => 'Proposta',
			'add_new_item'       => 'Nova proposta',
			'edit_item'          => 'Editar proposta',
			'new_item'           => 'Nova proposta',
			'view_item'          => 'Ver proposta',
			'search_items'       => 'Buscar propostas',
			'not_found'          => 'Nenhuma proposta encontrada',
			'not_found_in_trash' => 'Nenhuma proposta na lixeira',
			'menu_name'          => 'Propostas',
		];

		register_post_type( self::POST_TYPE, [
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => 'edit.php?post_type=' . Package::POST_TYPE,
			'show_in_rest'        => true,
			'rest_base'           => 'revela-proposals',
			'rest_controller_class' => 'WP_REST_Posts_Controller',
			'supports'            => [ 'title', 'custom-fields' ],
			'has_archive'         => false,
			'rewrite'             => [ 'slug' => 'proposta', 'with_front' => false ],
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
		] );
	}

	public static function get_statuses(): array {
		return self::$statuses;
	}

	public static function generate_token(): string {
		return bin2hex( random_bytes( 16 ) );
	}

	public static function get_meta_keys(): array {
		return [
			'package_id'       => self::META_PREFIX . 'package_id',
			'extras'           => self::META_PREFIX . 'extras',
			'client_email'     => self::META_PREFIX . 'client_email',
			'event_date'       => self::META_PREFIX . 'event_date',
			'delivery_days'    => self::META_PREFIX . 'delivery_days',
			'client_cnpj'      => self::META_PREFIX . 'client_cnpj',
			'selected_plan'    => self::META_PREFIX . 'selected_plan',
			'extra_clauses'    => self::META_PREFIX . 'extra_clauses',
			'client_data'      => self::META_PREFIX . 'client_data',
			'client_locals'    => self::META_PREFIX . 'client_locals',
			'entry_value'      => self::META_PREFIX . 'entry_value',
			'acceptance'       => self::META_PREFIX . 'acceptance',
			'token'            => self::META_PREFIX . 'token',
			'status'           => self::META_PREFIX . 'status',
			'created_at'       => self::META_PREFIX . 'created_at',
			'expires_at'       => self::META_PREFIX . 'expires_at',
		];
	}

	public static function get_meta( int $post_id, string $key ): mixed {
		$keys = self::get_meta_keys();
		if ( ! isset( $keys[ $key ] ) ) {
			return null;
		}
		return get_post_meta( $post_id, $keys[ $key ], true );
	}

	public static function set_meta( int $post_id, string $key, mixed $value ): bool {
		$keys = self::get_meta_keys();
		if ( ! isset( $keys[ $key ] ) ) {
			return false;
		}
		return update_post_meta( $post_id, $keys[ $key ], $value );
	}

	public static function delete_meta( int $post_id, string $key ): bool {
		$keys = self::get_meta_keys();
		if ( ! isset( $keys[ $key ] ) ) {
			return false;
		}
		return delete_post_meta( $post_id, $keys[ $key ] );
	}

	public static function find_by_token( string $token ): ?\WP_Post {
		$q = get_posts( [
			'post_type'      => self::POST_TYPE,
			'numberposts'    => 1,
			'meta_key'       => self::META_PREFIX . 'token',
			'meta_value'     => $token,
			'post_status'    => 'any',
		] );
		return $q ? $q[0] : null;
	}

	public static function is_valid_status( string $status ): bool {
		return isset( self::$statuses[ $status ] );
	}

	public static function get_rest_data( int $post_id ): array {
		$keys = self::get_meta_keys();
		$data = [];
		foreach ( $keys as $short => $full ) {
			$data[ $short ] = get_post_meta( $post_id, $full, true );
		}
		$data['status_label'] = self::$statuses[ $data['status'] ?? 'draft' ] ?? 'Desconhecido';
		return $data;
	}
}