<?php
/**
 * Contract template - printed via window.print() to PDF
 * Variables available: $ctx (ProposalData), $clauses (array)
 */
?>
<!doctype html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contrato - <?php echo esc_html( $ctx->client_name ?? '' ); ?></title>
	<style>
		@page { margin: 18mm 16mm; }
		* { box-sizing: border-box; }
		body { font-family: Georgia, "Times New Roman", serif; font-size: 11pt; line-height: 1.6; color: #1A1D1F; margin: 0; padding: 0; }
		.doc-head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1A1D1F; padding-bottom: 12px; margin-bottom: 24px; }
		.studio { font-size: 1.4rem; font-weight: 700; }
		.stitle { font-family: system-ui, sans-serif; font-size: 0.72rem; letter-spacing: 0.06em; text-transform: uppercase; color: #5A6068; margin-top: 4px; }
		.doc-date { font-family: system-ui, sans-serif; font-size: 0.72rem; color: #5A6068; text-align: right; }
		.doc-title { text-align: center; font-size: 1.15rem; margin: 22px 0 4px; }
		.doc-title small { display: block; font-family: system-ui, sans-serif; font-size: 0.66rem; letter-spacing: 0.14em; text-transform: uppercase; color: #5A6068; margin-top: 5px; font-weight: 400; }
		.sec { font-family: system-ui, sans-serif; font-size: 0.66rem; letter-spacing: 0.14em; text-transform: uppercase; color: #1C5D7C; font-weight: 700; margin: 22px 0 8px; }
		table.kv { width: 100%; border-collapse: collapse; font-family: system-ui, sans-serif; font-size: 0.82rem; margin-bottom: 16px; }
		table.kv td { padding: 7px 0; border-bottom: 1px solid #E4E4DE; vertical-align: top; }
		table.kv td:first-child { color: #5A6068; width: 40%; }
		table.kv tr.tot td { font-weight: 700; border-bottom: 0; }
		.clause { margin: 12px 0; }
		.clause b { display: block; font-family: system-ui, sans-serif; font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 3px; }
		.clause span { display: block; text-align: justify; font-size: 0.9rem; }
		.closing { text-align: justify; margin: 16px 0 0; font-size: 0.9rem; }
		.aceite { font-family: system-ui, sans-serif; font-size: 0.76rem; color: #5A6068; background: #F3F5F6; border-left: 3px solid #1C5D7C; padding: 8px 12px; margin: 16px 0 0; border-radius: 4px; }
		.signs { display: flex; gap: 30px; margin-top: 40px; }
		.signs > div { flex: 1; text-align: center; }
		.signs .rule { border-top: 1px solid #1A1D1F; margin-bottom: 6px; }
		.signs small { font-family: system-ui, sans-serif; font-size: 0.72rem; color: #5A6068; }
		.doc-foot { text-align: center; font-family: system-ui, sans-serif; font-size: 0.68rem; color: #5A6068; margin-top: 26px; }
		.revela-toolbar { display: none; }
		.client-header { font-weight: bold; }
	</style>
</head>
<body>
	<div class="revela-toolbar">
		<button type="button" onclick="window.print()">Baixar contrato em PDF</button>
	</div>
	<article class="revela-doc">
		<div class="doc-head">
			<div>
				<div class="studio"><?php echo esc_html( $ctx->settings['estudio'] ?? '' ); ?></div>
				<div class="stitle"><?php echo esc_html( trim( ( $ctx->settings['responsavel'] ?? '' ) . ( ( $ctx->settings['contato'] ?? '' ) ? ' · ' . $ctx->settings['contato'] : '' ), ' ·' ) ); ?></div>
			</div>
			<div class="doc-date"><?php echo esc_html( $ctx->settings['cidade_assin'] ?? '' ) . ', ' . $ctx->data_extenso( gmdate( 'Y-m-d' ) ); ?></div>
		</div>

		<h1 class="doc-title">Contrato de Prestação de Serviços Fotográficos<small><?php echo esc_html( $ctx->package_category ?? 'Fotografia' ); ?></small></h1>

		<div class="sec">Contratada & Contratante</div>
		<table class="kv">
			<tr><td>Contratada</td><td><?php echo esc_html( $ctx->settings['estudio'] ?? '' ); ?></td></tr>
			<tr class="client-header"><td>Contratante</td><td><?php echo esc_html( $ctx->client_name ); ?><?php echo ! empty( $ctx->event_date_ext ) ? ' — ' . esc_html( $ctx->event_date_ext ) : ''; ?></td></tr>
			<tr><td>CPF</td><td><?php echo esc_html( $ctx->client_cpf ); ?></td></tr>
			<tr><td>E-mail</td><td><?php echo esc_html( $ctx->client_email ); ?></td></tr>
			<?php if ( ! empty( $ctx->client_address ) ) : ?><tr><td>Endereço</td><td><?php echo esc_html( $ctx->client_address ); ?></td></tr><?php endif; ?>
		</table>

		<div class="sec">Pacote & Investimento</div>
		<table class="kv">
			<tr><td>Pacote</td><td><?php echo esc_html( $ctx->package_title ); ?></td></tr>
			<?php if ( $ctx->package_hours ) : ?><tr><td>Horas de cobertura</td><td><?php echo esc_html( $ctx->package_hours . 'h' ); ?></td></tr><?php endif; ?>
			<?php if ( $ctx->package_includes ) : ?><tr><td style="vertical-align:top;">Inclui</td><td style="text-align:left;white-space:pre-wrap;"><?php echo esc_html( $ctx->package_includes ); ?></td></tr><?php endif; ?>
			<?php foreach ( $ctx->extras as $ex ) : ?>
				<tr><td>Extra</td><td><?php echo esc_html( $ex['nome'] . ' — R$ ' . number_format( $ex['preco'], 2, ',', '.' ) ); ?></td></tr>
			<?php endforeach; ?>
			<?php if ( $ctx->selected_plan ) : ?>
				<tr><td>Plano de pagamento</td><td><?php echo esc_html( $ctx->selected_plan ); ?></td></tr>
				<?php if ( $ctx->payment_plans && isset( $ctx->payment_plans[0]['num_parcelas'] ) && $ctx->payment_plans[0]['num_parcelas'] === 0 ) : ?>
					<tr><td>Entrada (<?php echo esc_html( $ctx->payment_plans[0]['entrada_pct'] ?? 30 ); ?>%)</td><td><?php echo 'R$ ' . number_format( $ctx->entry_value > 0 ? $ctx->entry_value : $ctx->package_price * 0.3, 2, ',', '.' ); ?></td></tr>
				<?php else : ?>
					<tr><td>Entrada (<?php echo esc_html( $ctx->payment_plans[0]['entrada_pct'] ?? 30 ); ?>%)</td><td><?php echo 'R$ ' . number_format( $ctx->entry_value > 0 ? $ctx->entry_value : $ctx->package_price * 0.3, 2, ',', '.' ); ?></td></tr>
					<tr><td>Saldo parcelado</td><td><?php echo esc_html( $ctx->payment_plans[0]['num_parcelas'] ?? 0 ); ?>× de R$ <?php echo number_format( $ctx->payment_plans[0]['preview']['valor_parcela'] ?? 0, 2, ',', '.' ); ?></td></tr>
				<?php endif; ?>
			<?php else : ?>
				<tr><td>Entrada</td><td><?php echo 'R$ ' . number_format( $ctx->entry_value > 0 ? $ctx->entry_value : $ctx->package_price * 0.3, 2, ',', '.' ); ?></td></tr>
				<tr><td>Saldo</td><td><?php echo 'R$ ' . number_format( $ctx->package_price * 0.7, 2, ',', '.' ); ?></td></tr>
			<?php endif; ?>
			<tr class="tot"><td>Total</td><td><?php echo 'R$ ' . number_format( $ctx->package_price + array_sum( array_column( $ctx->extras, 'preco' ) ), 2, ',', '.' ); ?></td></tr>
		</table>

		<div class="sec">Locais do Evento</div>
		<table class="kv">
			<?php foreach ( $ctx->client_locals as $k => $v ) : ?>
				<tr><td><?php echo esc_html( ucfirst( str_replace( '_', ' ', $k ) ) ); ?></td><td><?php echo esc_html( $v ?: '—' ); ?></td></tr>
			<?php endforeach; ?>
		</table>

		<div class="sec">Cláusulas Contratuais</div>
		<?php foreach ( $clauses as $i => $cl ) : ?>
			<div class="clause"><b>Cláusula <?php echo $i + 1; ?> — <?php echo esc_html( $cl['title'] ); ?></b><span><?php echo esc_html( $cl['text'] ); ?></span></div>
		<?php endforeach; ?>

		<p class="closing">E, por estarem de acordo, as partes assinam o presente Contrato em 02 (duas) vias de igual teor e forma, para um só efeito.</p>
		<p class="closing"><?php echo esc_html( ( $ctx->settings['cidade_assin'] ?? '' ) . ', ' . $ctx->data_extenso( gmdate( 'Y-m-d' ) ) . '.' ); ?></p>

		<?php if ( ! empty( $ctx->acceptance['data'] ) ) : ?>
			<p class="aceite">✓ Aceite eletrônico registrado em <?php echo esc_html( $ctx->acceptance['data'] ); ?> por <?php echo esc_html( $ctx->acceptance['nome'] ); ?><?php echo ! empty( $ctx->acceptance['ip'] ) ? ' (IP ' . esc_html( $ctx->acceptance['ip'] ) . ')' : ''; ?>, mediante concordância com os valores e as cláusulas apresentados.</p>
		<?php endif; ?>

		<div class="signs">
			<div><div class="rule"></div><small><?php echo esc_html( $ctx->client_name ?? 'Contratante' ); ?><br>Contratante</small></div>
			<div><div class="rule"></div><small><?php echo esc_html( $ctx->settings['responsavel'] ? $ctx->settings['responsavel'] : $ctx->settings['estudio'] ); ?><br>Contratada</small></div>
		</div>
		<div class="doc-foot">Modelo gerado com REVELA v3 · recomenda-se revisão jurídica antes da assinatura</div>
	</article>
	<script>window.onload = function() { window.print(); }</script>
</body>
</html>