import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import { useBlockProps, InspectorControls, useSelect, useDispatch } from '@wordpress/block-editor';
import { PanelBody, TextControl, NumberControl, SelectControl, Button, DatePicker, ToggleControl, BaseControl, Notice } from '@wordpress/components';
import { useState, useEffect, useCallback } from '@wordpress/element';
import { apiFetch } from '@wordpress/api-fetch';
import './style.css';

const CATEGORIES = [
	{ value: 'casamento', label: 'Casamento' },
	{ value: 'prewedding', label: 'Pré-wedding' },
	{ value: 'formatura', label: 'Formatura' },
	{ value: 'evento', label: 'Evento' },
];

const formatBRL = ( val ) => {
	if ( val === undefined || val === null ) return '—';
	return 'R$ ' + Number( val ).toLocaleString( 'pt-BR', { minimumFractionDigits: 2 } );
};

registerBlockType( 'revela/proposal-block', {
	title: __( 'Proposta REVELA', 'revela-contratos' ),
	description: __( 'Crie propostas para clientes com seleção de pacote e plano', 'revela-contratos' ),
	category: 'revela',
	icon: 'welcome-write-blog',
	supports: {
		align: [ 'wide', 'full' ],
	},
	attributes: {
		package_id: { type: 'number', default: 0 },
		extras: { type: 'array', default: [] },
		client_email: { type: 'string', default: '' },
		event_date: { type: 'string', default: '' },
		delivery_days: { type: 'number', default: 60 },
		client_cnpj: { type: 'string', default: '' },
		selected_plan: { type: 'string', default: '' },
		extra_clauses: { type: 'string', default: '' },
		clientName: { type: 'string', default: '' },
	},
	edit: ( { attributes, setAttributes } ) => {
		const blockProps = useBlockProps();

		const [packages, setPackages] = useState( [] );
		const [loading, setLoading] = useState( true );
		const [creating, setCreating ] = useState( false );
		const [error, setError ] = useState( null );
		const [success, setSuccess ] = useState( null );

		const fetchPackages = useCallback( async () => {
			try {
				const data = await apiFetch( { path: '/revela/v3/packages' } );
				setPackages( data );
			} catch ( err ) {
				console.error( err );
			} finally {
				setLoading( false );
			}
		}, [] );

		useEffect( () => {
			fetchPackages();
		}, [ fetchPackages ] );

		const handleCreate = async () => {
			if ( ! attributes.package_id || ! attributes.clientName ) {
				setError( 'Selecione um pacote e informe o nome do cliente' );
				return;
			}

			setCreating( true );
			setError( null );
			setSuccess( null );

			try {
				const res = await apiFetch( {
					path: '/revela/v3/propostas',
					method: 'POST',
					data: {
						package_id: attributes.package_id,
						client_name: attributes.clientName,
						client_email: attributes.client_email,
						event_date: attributes.event_date,
						extras: attributes.extras,
						selected_plan: attributes.selected_plan,
						delivery_days: attributes.delivery_days,
						client_cnpj: attributes.client_cnpj,
						extra_clauses: attributes.extra_clauses,
					},
				} );

				setSuccess( 'Proposta criada! Link: ' + res.url );
				setAttributes( {
					clientName: '',
					client_email: '',
					event_date: '',
					extras: [],
					selected_plan: '',
					client_cnpj: '',
					extra_clauses: '',
					package_id: 0,
				} );
			} catch ( e ) {
				setError( e.message || 'Erro ao criar proposta' );
			} finally {
				setCreating( false );
			}
		};

		const pkg = packages.find( p => p.id === attributes.package_id );
		const plans = pkg?.payment_plans || [];

		return (
			<div { ...blockProps } className="revela-proposal-block">
				<div className="revela-block-header">
					<h3>Nova Proposta</h3>
					<p className="revela-subtitle">Preencha os dados e clique em Criar para gerar o link do cliente</p>
				</div>

				{loading && <div className="revela-loading">Carregando pacotes...</div>}

				{error && <Notice status="error" isDismissible={true} onRemove={ () => setError( null ) }>{error}</Notice>}
				{success && <Notice status="success" isDismissible={true} onRemove={ () => setSuccess( null ) }>{success}</Notice>}

				<SelectControl
					label="Pacote principal"
					value={ attributes.package_id }
					options={ [ { value: 0, label: '— selecione —' }, ...packages.map( p => ( { value: p.id, label: `${p.title} — ${formatBRL( p.preco )} (${p.categoria})` } ) ) ] }
					onChange={ ( val ) => {
						setAttributes( { package_id: val, selected_plan: '' } );
					} }
				/>

				<div className="revela-field-group">
					<BaseControl label="Nome do cliente / casal">
						<input
							type="text"
							value={ attributes.clientName }
							onChange={ ( e ) => setAttributes( { clientName: e.target.value } ) }
							placeholder="Ana & Pedro"
							style={{ width: '100%', padding: '8px 12px', border: '1px solid #dcdcde', borderRadius: '4px', fontSize: '0.9375rem' }}
						/>
					</BaseControl>
				</div>

				<div className="revela-field-row">
					<div className="revela-field-group">
						<TextControl
							label="E-mail do cliente"
							value={ attributes.client_email }
							onChange={ ( val ) => setAttributes( { client_email: val } ) }
							placeholder="cliente@email.com"
						/>
					</div>
					<div className="revela-field-group">
						<DatePicker
							label="Data do evento"
							value={ attributes.event_date }
							onChange={ ( val ) => setAttributes( { event_date: val } ) }
							currentDate={ attributes.event_date || new Date().toISOString().split('T')[0] }
						/>
					</div>
				</div>

				<div className="revela-field-row">
					<div className="revela-field-group">
						<NumberControl
							label="Prazo de entrega (dias)"
							value={ attributes.delivery_days }
							onChange={ ( val ) => setAttributes( { delivery_days: val } ) }
							min={ 1 }
							max={ 365 }
						/>
					</div>
					<div className="revela-field-group">
						<TextControl
							label="CNPJ (opcional)"
							value={ attributes.client_cnpj }
							onChange={ ( val ) => setAttributes( { client_cnpj: val } ) }
							placeholder="00.000.000/0000-00"
						/>
					</div>
				</div>

				{ pkg && (
					<>
						<hr className="revela-divider" />
						<h4>Itens Extras</h4>
						<p className="revela-help">Marque os extras que o cliente deseja incluir</p>
						<div className="revela-extras-grid">
							{ packages
								.filter( p => p.categoria === 'extra' )
								.map( extra => (
									<label key={ extra.id } className="revela-extra-item">
										<input
											type="checkbox"
											checked={ attributes.extras.includes( extra.id ) }
											onChange={ ( e ) => setAttributes( {
												extras: e.target.checked
													? [ ...attributes.extras, extra.id ]
													: attributes.extras.filter( id => id !== extra.id )
											} ) }
										/>
										<span>{extra.title} — ${formatBRL( extra.preco )}</span>
									</label>
								) )
							}
						</div>

						<hr className="revela-divider" />
						<h4>Plano de Pagamento</h4>
						<p className="revela-help">O cliente verá este plano pré-selecionado (pode alterar)</p>
						{ plans.length > 0 ? (
							<div className="revela-plans-radio">
								{ plans.map( plan => (
									<label key={ plan.name } className="revela-plan-radio">
										<input
											type="radio"
											name="revela-selected-plan"
											value={ plan.name }
											checked={ attributes.selected_plan === plan.name }
											onChange={ () => setAttributes( { selected_plan: plan.name } ) }
										/>
										<div className="revela-plan-radio-content">
											<strong>{plan.name}</strong>
											{plan.num_parcelas === 0 ? (
												<span className="revela-avista">À vista — Entrada {plan.entrada_pct}%</span>
											) : (
												<span>Entrada {plan.entrada_pct}% + {plan.num_parcelas}×</span>
											)}
										</div>
									</label>
								) )}
							</div>
						) : (
							<p className="revela-warning">Nenhum plano definido para este pacote. Edite o pacote para adicionar planos.</p>
						)}
					</>
				)}

				<hr className="revela-divider" />
				<h4>Cláusulas Extras (opcional)</h4>
				<BaseControl label="Observações específicas para este contrato">
					<TextareaControl
						value={ attributes.extra_clauses }
						onChange={ ( val ) => setAttributes( { extra_clauses: val } ) }
						rows={ 3 }
						placeholder="Adicione cláusulas específicas, observações ou pontos extras..."
					/>
				</BaseControl>

				<div className="revela-actions">
					<Button isPrimary isLarge onClick={ handleCreate } disabled={ loading || creating || !attributes.package_id }>
						{ creating ? 'Criando...' : 'Criar Proposta e Gerar Link' }
					</Button>
				</div>
			</div>
		);
	},
	save: () => null,
} );