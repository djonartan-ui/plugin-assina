<?php

namespace Revela\Blocks;

use Revela\Models\Proposal;
use Revela\Services\ContractService;
use Revela\Admin\Assets;

final class ClientFormShortcode {

	public static function render( array $atts ): string {
		$atts = shortcode_atts( [ 'token' => '' ], $atts );

		$token = sanitize_text_field( $atts['token'] );

		if ( $token === '' ) {
			return '<div class="revela-form-error" style="padding:20px;background:#fbeaea;border:1px solid #d63638;border-radius:8px;color:#a4262c;">Token da proposta não informado. Use: <code>[revela_proposta token="SEU_TOKEN"]</code></div>';
		}

		if ( ! preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			return '<div class="revela-form-error" style="padding:20px;background:#fbeaea;border:1px solid #d63638;border-radius:8px;color:#a4262c;">Token inválido.</div>';
		}

		$proposal = Proposal::find_by_token( $token );
		if ( ! $proposal ) {
			return '<div class="revela-form-error" style="padding:20px;background:#fbeaea;border:1px solid #d63638;border-radius:8px;color:#a4262c;">Proposta não encontrada.</div>';
		}

		$ctx = ContractService::instance()->build_context( $proposal->ID );
		if ( $ctx && $ctx->status === 'completed' ) {
			$url = add_query_arg( [ 'revela_token' => $token, 'view' => 'contrato' ], home_url( '/proposta/' ) );
			return '<div class="revela-form-completed" style="padding:20px;background:#e1f3e7;border:1px solid #4caf50;border-radius:8px;color:#2e7d32;"><p>Esta proposta já foi preenchida.</p><p><a href="' . esc_url( $url ) . '" class="button button-primary" target="_blank">Ver contrato</a></p></div>';
		}

		Assets::enqueue_frontend_assets();

		$api_url = rest_url( 'revela/v3/proposta/' . $token );

		ob_start();
		?>
		<div id="revela-client-app"
			 data-api-url="<?php echo esc_url( $api_url ); ?>"
			 data-token="<?php echo esc_attr( $token ); ?>"
			 data-nonce="<?php echo wp_create_nonce( 'wp_rest' ); ?>">
			<div class="revela-loading" style="padding:40px;text-align:center;color:#646970;font-family:system-ui,sans-serif;">Carregando proposta...</div>
		</div>
		<?php
		return ob_get_clean();
	}
}