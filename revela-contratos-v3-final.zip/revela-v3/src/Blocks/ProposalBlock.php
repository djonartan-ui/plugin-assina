<?php

namespace Revela\Blocks;

final class ProposalBlock {

	public static function register(): void {
		add_action( 'init', [ self::class, 'register_block_type' ] );
	}

	public static function register_block_type(): void {
		$block_dir = REVELA_DIR . '/build/proposal-block';
		$block_json = $block_dir . '/block.json';

		if ( is_dir( $block_dir ) && file_exists( $block_json ) ) {
			register_block_type( $block_dir );
		} else {
			register_block_type( 'revela/proposal-block', [
				'attributes'      => [],
				'render_callback' => [ self::class, 'render_fallback' ],
			] );
		}
	}

	public static function render_fallback( array $attributes, string $content ): string {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return '';
		}
		return '<div class="revela-block-notice" style="padding:16px;background:#fff3cd;border:1px solid #ffc107;border-radius:4px;color:#856404;">Bloco "Proposta REVELA" — compile os assets com <code>npm run build</code> para ver o editor completo.</div>';
	}
}