import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import { useBlockProps, InspectorControls, BlockControls, AlignmentToolbar } from '@wordpress/block-editor';
import { PanelBody, TextControl, NumberControl, SelectControl, Button, ToggleControl, BaseControl, TextareaControl } from '@wordpress/components';
import { useState, useEffect, useCallback } from '@wordpress/element';
import { apiFetch } from '@wordpress/api-fetch';
import './style.css';

const CATEGORIES = [
	{ value: 'casamento', label: 'Casamento' },
	{ value: 'prewedding', label: 'Pré-wedding' },
	{ value: 'formatura', label: 'Formatura' },
	{ value: 'evento', label: 'Evento' },
	{ value: 'extra', label: 'Extra' },
];

const DEFAULT_PLANS = [
	{ name: 'À vista (10% desc.)', entrada_pct: 10, num_parcelas: 0 },
	{ name: 'Entrada + 6×', entrada_pct: 30, num_parcelas: 6 },
	{ name: 'Entrada + 10×', entrada_pct: 30, num_parcelas: 10 },
	{ name: 'Entrada + 12×', entrada_pct: 30, num_parcelas: 12 },
];

const formatBRL = ( val ) => {
	if ( val === undefined || val === null ) return '—';
	return 'R$ ' + Number( val ).toLocaleString( 'pt-BR', { minimumFractionDigits: 2 } );
};

registerBlockType( 'revela/package-block', {
	title: __( 'Pacote REVELA', 'revela-contratos' ),
	description: __( 'Crie e edite pacotes fotográficos com planos de pagamento', 'revela-contratos' ),
	category: 'revela',
	icon: 'camera',
	supports: {
		align: [ 'wide', 'full' ],
		customClassName: true,
	},
	attributes: {
		categoria: { type: 'string', default: 'casamento' },
		preco: { type: 'number', default: 0 },
		horas: { type: 'number', default: 8 },
		inclui: { type: 'string', default: '' },
		parcelas_texto: { type: 'string', default: '' },
		paymentPlans: {
			type: 'array',
			default: DEFAULT_PLANS,
		},
	},
	edit: ( { attributes, setAttributes } ) => {
		const blockProps = useBlockProps();
		const [preco, setPreco] = useState( attributes.preco || 0 );
		const [paymentPlans, setPaymentPlans] = useState( attributes.paymentPlans || DEFAULT_PLANS );

		useEffect( () => { setPreco( attributes.preco || 0 ); }, [ attributes.preco ] );
		useEffect( () => { setPaymentPlans( attributes.paymentPlans || DEFAULT_PLANS ); }, [ attributes.paymentPlans ] );

		const calculateParcela = useCallback( ( plan, price ) => {
			if ( ! plan || ! price ) return 0;
			const entrada = price * ( plan.entrada_pct || 0 ) / 100;
			const saldo = price - entrada;
			return plan.num_parcelas > 0 ? saldo / plan.num_parcelas : 0;
		}, [] );

		const updatePlan = ( index, field, value ) => {
			const newPlans = [ ...paymentPlans ];
			newPlans[ index ] = { ...newPlans[ index ], [ field ]: value };
			setPaymentPlans( newPlans );
			setAttributes( { paymentPlans: newPlans } );
		};

		const addPlan = () => {
			const newPlans = [ ...paymentPlans, { name: '', entrada_pct: 30, num_parcelas: 6 } ];
			setPaymentPlans( newPlans );
			setAttributes( { paymentPlans: newPlans } );
		};

		const removePlan = ( index ) => {
			if ( paymentPlans.length <= 1 ) return;
			const newPlans = paymentPlans.filter( ( _, i ) => i !== index );
			setPaymentPlans( newPlans );
			setAttributes( { paymentPlans: newPlans } );
		};

		const movePlan = ( index, direction ) => {
			const newIndex = index + direction;
			if ( newIndex < 0 || newIndex >= paymentPlans.length ) return;
			const newPlans = [ ...paymentPlans ];
			[ newPlans[ index ], newPlans[ newIndex ] ] = [ newPlans[ newIndex ], newPlans[ index ] ];
			setPaymentPlans( newPlans );
			setAttributes( { paymentPlans: newPlans } );
		};

		return (
			<div { ...blockProps } className="revela-package-block">
				<div className="revela-block-header">
					<h3>Pacote Fotográfico</h3>
				</div>

				<div className="revela-field-group">
					<SelectControl
						label="Categoria"
						value={ attributes.categoria }
						options={ CATEGORIES }
						onChange={ ( val ) => setAttributes( { categoria: val } ) }
					/>
				</div>

				<div className="revela-field-row">
					<div className="revela-field-group">
						<NumberControl
							label="Preço (R$)"
							value={ preco }
							onChange={ ( val ) => {
								setPreco( val );
								setAttributes( { preco: val } );
							} }
							min={ 0 }
							step={ 1 }
						/>
					</div>
					<div className="revela-field-group">
						<NumberControl
							label="Horas de cobertura"
							value={ attributes.horas }
							onChange={ ( val ) => setAttributes( { horas: val } ) }
							min={ 1 }
							max={ 16 }
						/>
					</div>
				</div>

				<div className="revela-field-group">
					<TextControl
						label="Condição geral / parcelas (fallback)"
						value={ attributes.parcelas_texto }
						onChange={ ( val ) => setAttributes( { parcelas_texto: val } ) }
						help="Texto livre usado como fallback se nenhum plano for definido"
					/>
				</div>

				<div className="revela-field-group">
					<BaseControl label="Inclui / Descrição">
						<TextareaControl
							value={ attributes.inclui }
							onChange={ ( val ) => setAttributes( { inclui: val } ) }
							rows={ 3 }
							placeholder="Cobertura, nº de fotos, álbum..."
						/>
					</BaseControl>
				</div>

				<hr className="revela-divider" />

				<div className="revela-section-header">
					<h4>Planos de Pagamento</h4>
					<p className="revela-help">O cliente escolhe um destes planos ao preencher a proposta.</p>
				</div>

				<div className="revela-plans-table">
					<div className="revela-plan-headers">
						<div className="revela-plan-col name">Nome do Plano</div>
						<div className="revela-plan-col entrada">Entrada (%)</div>
						<div className="revela-plan-col parcelas">Nº Parcelas</div>
						<div className="revela-plan-col valor">Valor da Parcela</div>
						<div className="revela-plan-col order">Ordem</div>
						<div className="revela-plan-col actions"></div>
					</div>
					{paymentPlans.map( ( plan, index ) => (
						<div key={ index } className="revela-plan-row">
							<div className="revela-plan-col name">
								<input
									type="text"
									value={ plan.name }
									onChange={ ( e ) => updatePlan( index, 'name', e.target.value ) }
									placeholder="Ex: À vista 10% | Entrada + 6×"
									style={{ width: '100%' }}
								/>
							</div>
							<div className="revela-plan-col entrada">
								<NumberControl
									value={ plan.entrada_pct }
									onChange={ ( val ) => updatePlan( index, 'entrada_pct', val ) }
									min={ 0 }
									max={ 100 }
									step={ 1 }
									label={ false }
								/>
							</div>
							<div className="revela-plan-col parcelas">
								<NumberControl
									value={ plan.num_parcelas }
									onChange={ ( val ) => updatePlan( index, 'num_parcelas', val ) }
									min={ 0 }
									max={ 60 }
									step={ 1 }
									label={ false }
								/>
							</div>
							<div className="revela-plan-col valor">
								<span className="revela-plan-preview">
									{calculateParcela( plan, preco ) > 0 ? formatBRL( calculateParcela( plan, preco ) ) : '—'}
								</span>
							</div>
							<div className="revela-plan-col order">
								<div className="revela-move-buttons">
									<Button
										isDefault
										size="small"
										onClick={ () => movePlan( index, -1 ) }
										disabled={ index === 0 }
										aria-label={ __( 'Mover para cima', 'revela-contratos' ) }
									>
										↑
									</Button>
									<Button
										isDefault
										size="small"
										onClick={ () => movePlan( index, 1 ) }
										disabled={ index === paymentPlans.length - 1 }
										aria-label={ __( 'Mover para baixo', 'revela-contratos' ) }
									>
										↓
									</Button>
								</div>
							</div>
							<div className="revela-plan-col actions">
								<Button
									isDestructive
									size="small"
									onClick={ () => removePlan( index ) }
									disabled={ paymentPlans.length <= 1 }
									aria-label={ __( 'Remover plano', 'revela-contratos' ) }
								>
									🗑
								</Button>
							</div>
						</div>
					) )}
				</div>

				<Button isSecondary onClick={ addPlan } className="revela-add-plan-btn">
					+ Adicionar Plano
				</Button>
			</div>
		);
	},
	save: () => null,
} );