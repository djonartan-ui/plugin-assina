<?php

namespace Revela\Services;

final class SecurityService {

	private static ?self $instance = null;

	private function __construct() {}

	public static function instance(): self {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function verify_nonce( string $action, string $nonce_field = '_wpnonce' ): bool {
		if ( empty( $_POST[ $nonce_field ] ) ) {
			return false;
		}
		return wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $nonce_field ] ) ), $action );
	}

	public function create_nonce( string $action, string $nonce_field = '_wpnonce' ): string {
		return wp_create_nonce( $action );
	}

	public function get_nonce_field( string $action, string $name = '_wpnonce', bool $referer = true, bool $echo = true ): string {
		return wp_nonce_field( $action, $name, $referer, $echo );
	}

	public function check_rate_limit( string $action, int $limit = 10, int $window = 60 ): bool {
		$key = 'revela_rate_' . $action . '_' . $this->get_client_identifier();
		$count = get_transient( $key );

		if ( $count === false ) {
			set_transient( $key, 1, $window );
			return true;
		}

		if ( $count >= $limit ) {
			return false;
		}

		set_transient( $key, $count + 1, $window );
		return true;
	}

	public function get_client_identifier(): string {
		$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
		$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
		return substr( hash( 'sha256', $ip . $user_agent ), 0, 16 );
	}

	public function sanitize_filename( string $filename ): string {
		$filename = wp_basename( $filename );
		$filename = preg_replace( '/[^a-zA-Z0-9._-]/', '', $filename );
		return $filename;
	}

	public function validate_cpf( string $cpf ): bool {
		$cpf = preg_replace( '/[^0-9]/', '', $cpf );
		if ( strlen( $cpf ) !== 11 || preg_match( '/^(\d)\1{10}$/', $cpf ) ) {
			return false;
		}

		for ( $t = 9; $t < 11; $t++ ) {
			$sum = 0;
			for ( $i = 0; $i < $t; $i++ ) {
				$sum += (int) $cpf[ $i ] * ( $t + 1 - $i );
			}
			$digit = ( $sum * 10 ) % 11;
			if ( $digit === 10 ) { $digit = 0; }
			if ( (int) $cpf[ $t ] !== $digit ) {
				return false;
			}
		}
		return true;
	}

	public function validate_cnpj( string $cnpj ): bool {
		$cnpj = preg_replace( '/[^0-9]/', '', $cnpj );
		if ( strlen( $cnpj ) !== 14 ) {
			return false;
		}

		$weights1 = [ 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 ];
		$weights2 = [ 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 ];

		$sum = 0;
		for ( $i = 0; $i < 12; $i++ ) {
			$sum += (int) $cnpj[ $i ] * $weights1[ $i ];
		}
		$digit1 = $sum % 11;
		$digit1 = $digit1 < 2 ? 0 : 11 - $digit1;

		$sum = 0;
		for ( $i = 0; $i < 13; $i++ ) {
			$sum += (int) $cnpj[ $i ] * $weights2[ $i ];
		}
		$digit2 = $sum % 11;
		$digit2 = $digit2 < 2 ? 0 : 11 - $digit2;

		return (int) $cnpj[12] === $digit1 && (int) $cnpj[13] === $digit2;
	}
}