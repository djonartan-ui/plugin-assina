<?php

namespace Revela\Services;

final class SettingsService {

	private static ?self $instance = null;
	private array $settings = [];

	private function __construct() {
		$this->settings = $this->load();
	}

	public static function instance(): self {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function get_defaults(): array {
		return [
			'estudio'           => 'Ateliê Luz Natural',
			'responsavel'       => '',
			'contato'           => '',
			'documento'         => '',
			'email_estudio'     => '', // será preenchido em load() com fallback para admin_email
			'endereco_estudio'  => '',
			'site_estudio'      => '',
			'entrada_pct'       => 30,
			'validade_dias'     => 15,
			'entrega_dias'      => 60,
			'comarca'           => 'Igrejinha',
			'uf'                => 'RS',
			'refund_pct'        => 70,
			'backup_meses'      => 12,
			'nuvem_dias'        => 60,
			'taxa_arquivos'     => 150,
			'taxa_pendrive'     => 250,
			'cidade_assin'      => 'Igrejinha',
			'nonce_lifetime'    => 24,
			'max_file_size'     => 10,
		];
	}

	public function get( string $key, mixed $default = '' ): mixed {
		return $this->settings[ $key ] ?? $default;
	}

	public function get_all(): array {
		return $this->settings;
	}

	public function update( array $data ): array {
		$validator = new \Revela\Validators\SettingsValidator();
		$sanitized = $validator->sanitize( $data, $this->settings );

		update_option( 'revela_settings', $sanitized, 'no' );
		$this->settings = $sanitized;

		return $this->settings;
	}

	public function get_clause( string $key ): string {
		$field = 'clausula_' . $key;
		$defaults = self::get_default_clauses();
		return $this->settings[ $field ] ?? $defaults[ $key ]['text'] ?? '';
	}

	private function load(): array {
		$stored = get_option( 'revela_settings', [] );
		$defaults = self::get_defaults();

		$merged = array_merge( $defaults, $stored );

		// Fallback para email do admin se não configurado
		if ( empty( $merged['email_estudio'] ) ) {
			$merged['email_estudio'] = get_option( 'admin_email' );
		}

		foreach ( self::get_default_clauses() as $key => $clause ) {
			$field = 'clausula_' . $key;
			if ( ! isset( $merged[ $field ] ) ) {
				$merged[ $field ] = $clause['text'];
			}
		}

		return $merged;
	}

	public static function get_default_clauses(): array {
		return [
			'objeto'            => [ 'title' => 'OBJETO',                    'text' => 'A CONTRATADA prestará à CONTRATANTE serviços de {tipo}, a serem realizados em {local}, na data de {data_evento}. As imagens serão entregues tratadas em alta resolução, sem marca d\'água. Cobertura de {horas_cobertura} horas.' ],
			'pagamento'         => [ 'title' => 'PAGAMENTO',                 'text' => 'O valor total dos serviços é de {total}, sendo {entrada} ({entrada_pct}%) a título de reserva, pago na assinatura deste contrato, e o saldo de {saldo} quitado conforme plano escolhido: {plano_nome}. A data somente é reservada em agenda após a confirmação do pagamento de reserva.' ],
			'substituicao'      => [ 'title' => 'SUBSTITUIÇÃO',              'text' => 'Em caso de força maior em que a CONTRATADA não puder comparecer ao evento para realizar a cobertura fotográfica, ela fica responsável por definir e enviar outro profissional qualificado em seu lugar, sem custos adicionais para a CONTRATANTE.' ],
			'cancelamento'      => [ 'title' => 'CANCELAMENTO',              'text' => 'Caso o evento seja cancelado ou tenha a data remarcada por motivos de força maior, ficará a critério da CONTRATADA aceitar ou não a nova data, de acordo com sua disponibilidade. Não havendo possibilidade de remarcação, a CONTRATADA compromete-se a devolver à CONTRATANTE {refund_pct}% do valor já recebido, no prazo de até 12 (doze) meses a partir da data aqui firmada para o evento.' ],
			'entrega'           => [ 'title' => 'ENTREGA',                   'text' => 'O material será entregue em até {entrega_dias} dias após o evento. No ato da entrega, a CONTRATANTE conferirá o serviço e dará seu aceite, não cabendo futuras reclamações ou indenizações devido a descuidos ou mau manuseio do serviço já entregue.' ],
			'prazo_revelacao'   => [ 'title' => 'PRAZO PARA REVELAÇÃO/IMPRESSÃO', 'text' => 'O CLIENTE tem 30 (trinta) dias após o recebimento dos arquivos digitais em alta resolução para encaminhar à CONTRATADA o material que deseja revelar ou imprimir, sob pena de considerar-se concluída a obrigação de entrega.' ],
			'divulgacao'        => [ 'title' => 'DIVULGAÇÃO',                'text' => 'A CONTRATANTE autoriza o uso de todo o material produzido em portfólio, site, blog, redes sociais ou qualquer outro canal que a CONTRATADA venha a utilizar para promover o seu trabalho.' ],
			'arquivos'          => [ 'title' => 'ARQUIVOS DIGITAIS E BACKUP', 'text' => 'A CONTRATADA compromete-se a manter cópia dos arquivos digitais por {backup_meses} meses após a data do evento. Os arquivos ficarão disponíveis para acesso na nuvem por {nuvem_dias} dias após a entrega; após esse prazo, será cobrada taxa de {taxa_arquivos} para nova disponibilização. A CONTRATANTE receberá um pen drive contendo todo o material contratado; caso seja necessária a emissão de novo pen drive, será cobrada taxa de {taxa_pendrive}. Após o prazo de 2 (dois) anos, a CONTRATADA não se responsabiliza por manter os arquivos digitais, isentando-se de quaisquer responsabilidades futuras.' ],
			'lgpd'              => [ 'title' => 'PROTEÇÃO DE DADOS',         'text' => 'Os dados pessoais da CONTRATANTE (nome, CPF, endereço e contato) serão tratados exclusivamente para a execução deste contrato e o cumprimento de obrigações legais, nos termos da Lei nº 13.709/2018 (LGPD), não sendo compartilhados com terceiros sem autorização, salvo por exigência legal.' ],
			'foro'              => [ 'title' => 'FORO',                      'text' => 'Fica eleito o foro da Comarca de {comarca}, Estado {uf_nome}, para dirimir quaisquer questões judiciais decorrentes deste Contrato, com renúncia expressa a qualquer outro, por mais privilegiado que seja.' ],
		];
	}
}