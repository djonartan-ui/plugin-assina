<?php

namespace Revela\Services;

final class CleanupService {

	public static function run(): void {
		self::cleanup_expired_proposals();
		self::cleanup_orphaned_meta();
	}

	private static function cleanup_expired_proposals(): void {
		$expired = get_posts( [
			'post_type'      => \Revela\Models\Proposal::POST_TYPE,
			'numberposts'    => -1,
			'post_status'    => 'publish',
			'meta_query'     => [
				'relation' => 'AND',
				[
					'key'     => '_revela_status',
					'value'   => 'pending',
					'compare' => '=',
				],
				[
					'key'     => '_revela_expires_at',
					'value'   => current_time( 'mysql' ),
					'compare' => '<',
					'type'    => 'DATETIME',
				],
			],
			'fields'         => 'ids',
		] );

		foreach ( $expired as $post_id ) {
			update_post_meta( $post_id, '_revela_status', 'expired' );
		}
	}

	private static function cleanup_orphaned_meta(): void {
		$proposals = get_posts( [
			'post_type'      => \Revela\Models\Proposal::POST_TYPE,
			'numberposts'    => -1,
			'post_status'    => 'any',
			'fields'         => 'ids',
		] );

		foreach ( $proposals as $post_id ) {
			$package_id = get_post_meta( $post_id, '_revela_package_id', true );
			if ( $package_id && ! get_post( $package_id ) ) {
				update_post_meta( $post_id, '_revela_status', 'expired' );
			}
		}
	}
}