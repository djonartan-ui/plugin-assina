<?php

namespace Revela\Services;

use Revela\DTO\Money;
use Revela\DTO\ProposalData;

final class EmailService {

	private static ?self $instance = null;
	private SettingsService $settings;

	private function __construct() {
		$this->settings = SettingsService::instance();
	}

	public static function instance(): self {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function send_proposal_emails( int $proposal_id ): bool {
		$contract_service = ContractService::instance();
		$ctx = $contract_service->build_context( $proposal_id );
		if ( ! $ctx ) {
			return false;
		}

		$client = [
			'nome'      => $ctx->client_name,
			'email'     => $ctx->client_email,
		];
		$estudio = $ctx->settings['estudio'] ?? '';
		$to_studio = $ctx->settings['email_estudio'] ?? get_option( 'admin_email' );
		$token = $ctx->token ?? '';
		$url = $token ? add_query_arg( 'revela_token', $token, home_url( '/proposta/' ) ) : '';

		if ( ! is_email( $to_studio ) ) {
			return false;
		}

		$subj = 'Contrato — ' . $estudio . ' · ' . $ctx->package_title;
		$from_name = sanitize_text_field( $estudio );
		$headers = [
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $from_name . ' <' . $to_studio . '>',
		];

		$sent = true;

		if ( is_email( $client['email'] ) ) {
			$sent = wp_mail( $client['email'], $subj, $this->email_html( $ctx, $client, $url, false ), $headers ) && $sent;
		}

		if ( is_email( $to_studio ) ) {
			$sent = wp_mail( $to_studio, 'Nova proposta preenchida — ' . $client['nome'], $this->email_html( $ctx, $client, $url, true ), $headers ) && $sent;
		}

		return $sent;
	}

	private function email_html( ProposalData $ctx, array $client, string $url, bool $for_studio ): string {
		$estudio = $ctx->settings['estudio'] ?? '';
		$ola = $for_studio
			? 'O cliente <strong>' . esc_html( $client['nome'] ?? '' ) . '</strong> preencheu os dados. Contrato pronto:'
			: 'Olá, ' . esc_html( $client['nome'] ?? '' ) . '! Seu contrato com o ' . esc_html( $estudio ) . ' está pronto:';

		$total = new Money( $ctx->package_price + array_sum( array_column( $ctx->extras, 'preco' ) ) );
		$entrada = new Money( $ctx->entry_value > 0 ? $ctx->entry_value : $total->toFloat() * 0.3 );

		$linhas = [
			'Pacote'       => $ctx->package_title,
			'Investimento' => $total->format(),
			'Reserva'      => $entrada->format() . ' (30%)',
			'Saldo'        => $total->subtract( $entrada )->format(),
		];
		if ( $ctx->selected_plan ) {
			$linhas['Plano'] = $ctx->selected_plan;
		}

		$rows = '';
		foreach ( $linhas as $k => $v ) {
			$rows .= '<tr><td style="padding:6px 0;color:#5E6873;font-size:13px">' . esc_html( $k )
				. '</td><td style="padding:6px 0;text-align:right;font-size:13px">' . esc_html( $v ) . '</td></tr>';
		}

		return '<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;color:#14181B">'
			. '<div style="font-size:18px;letter-spacing:.3em;text-transform:uppercase;color:#1C5D7C;padding:8px 0">REVELA</div>'
			. '<p style="font-size:15px;line-height:1.5">' . $ola . '</p>'
			. '<table style="width:100%;border-collapse:collapse;border-top:1px solid #E4E4DE;border-bottom:1px solid #E4E4DE;margin:12px 0">' . $rows . '</table>'
			. '<p style="text-align:center;margin:22px 0">'
			. '<a href="' . esc_url( $url ) . '" style="background:#1C5D7C;color:#fff;text-decoration:none;padding:13px 26px;border-radius:10px;font-weight:bold;font-size:15px;display:inline-block">Ver e baixar o contrato (PDF)</a>'
			. '</p>'
			. '<p style="font-size:12px;color:#8A929A;text-align:center">Documento gerado com REVELA v3 · revise as cláusulas antes de assinar.</p>'
			. '</div>';
	}
}