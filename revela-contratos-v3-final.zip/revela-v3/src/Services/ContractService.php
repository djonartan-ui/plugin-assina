<?php

namespace Revela\Services;

use Revela\DTO\Money;
use Revela\DTO\ProposalData;
use Revela\Models\Package;
use Revela\Models\Proposal;

final class ContractService {

	private static ?self $instance = null;
	private SettingsService $settings;

	private function __construct() {
		$this->settings = SettingsService::instance();
	}

	public static function instance(): self {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function build_context( int $proposal_id ): ?ProposalData {
		$proposal = get_post( $proposal_id );
		if ( ! $proposal || $proposal->post_type !== Proposal::POST_TYPE ) {
			return null;
		}

		$meta_keys = Proposal::get_meta_keys();
		$meta = [];
		foreach ( $meta_keys as $short => $full ) {
			$meta[ $short ] = get_post_meta( $proposal_id, $full, true );
		}

		$package_id = (int) $meta['package_id'];
		$package = $package_id ? get_post( $package_id ) : null;

		if ( ! $package ) {
			return null;
		}

		$extra_ids = array_map( 'intval', (array) $meta['extras'] );
		$extra_items = [];
		$extra_total = 0.0;
		foreach ( $extra_ids as $eid ) {
			$price = (float) get_post_meta( $eid, Package::META_PREFIX . 'preco', true );
			$extra_total += $price;
			$extra_items[] = [ 'nome' => get_the_title( $eid ), 'preco' => $price ];
		}

		$pkg_price = Package::get_price( $package_id );
		$total = new Money( $pkg_price + $extra_total );

		$plans = Package::get_payment_plans( $package_id );
		$plan_name = $meta['selected_plan'] ?? ( $plans[0]['name'] ?? '' );
		$plan = null;
		foreach ( $plans as $p ) {
			if ( ( $p['name'] ?? '' ) === $plan_name ) {
				$plan = $p;
				break;
			}
		}

		$entrada_pct = $plan ? (int) $plan['entrada_pct'] : (int) $this->settings->get( 'entrada_pct', 30 );
		$num_parcelas = $plan ? (int) $plan['num_parcelas'] : 0;

		$entry_value = new Money( (float) $meta['entry_value'] );
		if ( $entry_value->isPositive() ) {
			$entrada = $entry_value->toFloat() > $total->toFloat() ? $total : $entry_value;
			$entrada_pct_calc = $total->toFloat() > 0 ? (int) round( $entrada->toFloat() / $total->toFloat() * 100 ) : $entrada_pct;
		} else {
			$entrada = $total->percentage( $entrada_pct );
			$entrada_pct_calc = $entrada_pct;
		}
		$saldo = $total->subtract( $entrada );

		$valor_parcela = Money::fromCents( 0 );
		if ( $num_parcelas > 0 && $saldo->isPositive() ) {
			$valor_parcela = $saldo->divide( $num_parcelas );
		}

		$entrega_dias = (int) $meta['delivery_days'];
		if ( ! $entrega_dias ) {
			$entrega_dias = (int) $this->settings->get( 'entrega_dias', 60 );
		}

		$data_evento = $meta['event_date'];
		$data_ext = $this->data_extenso( $data_evento );
		$hoje_ext = $this->data_extenso( gmdate( 'Y-m-d' ) );

		$client_data = (array) $meta['client_data'];
		$locals = (array) $meta['client_locals'];

		$s = $this->settings->get_all();

		return new ProposalData( [
			'proposal_id'      => $proposal_id,
			'package_id'       => $package_id,
			'package_title'    => $package->post_title,
			'package_price'    => $pkg_price,
			'package_category' => Package::get_category( $package_id ),
			'package_hours'    => Package::get_hours( $package_id ),
			'package_includes' => Package::get_includes( $package_id ),
			'payment_plans'    => $plans,
			'extras'           => $extra_items,
			'event_date'       => $data_evento,
			'event_date_ext'   => $data_ext,
			'delivery_days'    => $entrega_dias,
			'client_name'      => $client_data['nome'] ?? '',
			'client_cpf'       => $client_data['cpf'] ?? '',
			'client_email'     => $client_data['email'] ?? '',
			'client_address'   => $client_data['endereco'] ?? '',
			'client_cnpj'      => $meta['client_cnpj'] ?? '',
			'client_locals'    => $locals,
			'entry_value'      => $entry_value->toFloat(),
			'selected_plan'    => $plan_name,
			'status'           => $meta['status'] ?? 'draft',
			'token'            => $meta['token'] ?? '',
			'acceptance'       => (array) $meta['acceptance'],
			'settings'         => $s,
		] );
	}

	public function build_clauses( ProposalData $ctx ): array {
		$s = $ctx->settings;
		$clauses_default = SettingsService::get_default_clauses();
		$clauses = [];

		$vars = [
			'estudio'           => $s['estudio'] ?? '',
			'responsavel'       => $s['responsavel'] ?? '',
			'contratante'       => $ctx->client_name ?: '{contratante}',
			'cpf'               => $ctx->client_cpf ?: '{cpf}',
			'cnpj'              => $ctx->client_cnpj ?: '{cnpj}',
			'email'             => $ctx->client_email ?: '{email}',
			'endereco'          => $ctx->client_address ?: '{endereco}',
			'pacote'            => $ctx->package_title ?: '{pacote}',
			'inclui'            => $ctx->package_includes ?: '{inclui}',
			'extras'            => ! empty( $ctx->extras ) ? implode( ', ', array_column( $ctx->extras, 'nome' ) ) : '{extras}',
			'total'             => (new Money( $ctx->package_price + array_sum( array_column( $ctx->extras, 'preco' ) ) ))->format(),
			'entrada'           => (new Money( $ctx->entry_value ))->format(),
			'saldo'             => (new Money( (new Money( $ctx->package_price + array_sum( array_column( $ctx->extras, 'preco' ) )))->toFloat() - $ctx->entry_value ))->format(),
			'entrada_pct'       => $ctx->selected_plan ? ( $ctx->payment_plans[0]['entrada_pct'] ?? 30 ) : ( $s['entrada_pct'] ?? 30 ),
			'entrega_dias'      => $ctx->delivery_days ?? '{entrega_dias}',
			'refund_pct'        => $s['refund_pct'] ?? '{refund_pct}',
			'backup_meses'      => $s['backup_meses'] ?? '{backup_meses}',
			'nuvem_dias'        => $s['nuvem_dias'] ?? '{nuvem_dias}',
			'taxa_arquivos'     => (new Money( $s['taxa_arquivos'] ?? 0 ))->format(),
			'taxa_pendrive'     => (new Money( $s['taxa_pendrive'] ?? 0 ))->format(),
			'comarca'           => $s['comarca'] ?? '{comarca}',
			'uf'                => $s['uf'] ?? '{uf}',
			'uf_nome'           => $this->uf_nome( $s['uf'] ?? '' ),
			'cidade_assin'      => $s['cidade_assin'] ?? '{cidade_assin}',
			'data_evento'       => $ctx->event_date_ext ?? '{data_evento}',
			'data_hoje'         => $this->data_extenso( gmdate( 'Y-m-d' ) ),
			'horas_cobertura'   => $ctx->package_hours ?? '{horas_cobertura}',
			'tipo'              => $ctx->package_category ?? 'fotografia',
			'local'             => implode( ', ', array_filter( $ctx->client_locals ) ),
			'plano_nome'        => $ctx->selected_plan ?? '{plano_nome}',
			'num_parcelas'      => $ctx->selected_plan ? ( $ctx->payment_plans[0]['num_parcelas'] ?? 0 ) : 0,
			'valor_parcela'     => (new Money( 0 ))->format(),
			'endereco_estudio'  => $s['endereco_estudio'] ?? '',
			'site_estudio'      => $s['site_estudio'] ?? '',
			'documento_estudio' => $s['documento'] ?? '',
			'extras_texto'      => $meta['extra_clauses'] ?? '',
		];

		foreach ( $clauses_default as $key => $clause ) {
			$field = 'clausula_' . $key;
			$text = $s[ $field ] ?? $clause['text'];
			$clauses[] = [
				'title' => $clause['title'],
				'text'  => strtr( $text, $vars ),
			];
		}

		return $clauses;
	}

	public function render_contract_html( int $proposal_id ): string {
		$ctx = $this->build_context( $proposal_id );
		if ( ! $ctx ) {
			return '<p>Proposta não encontrada.</p>';
		}

		$clauses = $this->build_clauses( $ctx );

		ob_start();
		include REVELA_DIR . '/src/templates/contract.php';
		return ob_get_clean();
	}

	private function uf_nome( string $uf ): string {
		$map = [
			'AC' => 'Acre', 'AL' => 'Alagoas', 'AP' => 'Amapá', 'AM' => 'Amazonas',
			'BA' => 'Bahia', 'CE' => 'Ceará', 'DF' => 'Distrito Federal', 'ES' => 'Espírito Santo',
			'GO' => 'Goiás', 'MA' => 'Maranhão', 'MT' => 'Mato Grosso', 'MS' => 'Mato Grosso do Sul',
			'MG' => 'Minas Gerais', 'PA' => 'Pará', 'PB' => 'Paraíba', 'PR' => 'Paraná',
			'PE' => 'Pernambuco', 'PI' => 'Piauí', 'RJ' => 'Rio de Janeiro', 'RN' => 'Rio Grande do Norte',
			'RS' => 'Rio Grande do Sul', 'RO' => 'Rondônia', 'RR' => 'Roraima', 'SC' => 'Santa Catarina',
			'SP' => 'São Paulo', 'SE' => 'Sergipe', 'TO' => 'Tocantins',
		];
		$uf = strtoupper( trim( $uf ) );
		return $map[ $uf ] ?? $uf;
	}

	private function data_extenso( string $iso ): string {
		if ( ! $iso ) {
			return '';
		}
		$p = explode( '-', $iso );
		if ( count( $p ) !== 3 ) {
			return $iso;
		}
		$meses = [ '', 'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro' ];
		return (int) $p[2] . ' de ' . $meses[ (int) $p[1] ] . ' de ' . $p[0];
	}
}